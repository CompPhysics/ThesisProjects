This IPython notebook ExptML.ipynb does not require any additional
programs.

This IPython notebook RNNquantum.ipynb does not require any additional
programs.

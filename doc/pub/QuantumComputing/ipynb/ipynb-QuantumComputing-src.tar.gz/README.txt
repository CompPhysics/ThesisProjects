This IPython notebook QuantumComputing.ipynb does not require any additional
programs.

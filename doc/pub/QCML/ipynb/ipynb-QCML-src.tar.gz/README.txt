This IPython notebook QCML.ipynb does not require any additional
programs.

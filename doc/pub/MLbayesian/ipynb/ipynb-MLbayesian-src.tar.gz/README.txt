This IPython notebook MLbayesian.ipynb does not require any additional
programs.

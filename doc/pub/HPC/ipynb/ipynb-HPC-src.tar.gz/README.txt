This IPython notebook HPC.ipynb does not require any additional
programs.

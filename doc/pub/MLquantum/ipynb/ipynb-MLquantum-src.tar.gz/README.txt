This IPython notebook MLquantum.ipynb does not require any additional
programs.

This IPython notebook InfiniteMatter.ipynb does not require any additional
programs.

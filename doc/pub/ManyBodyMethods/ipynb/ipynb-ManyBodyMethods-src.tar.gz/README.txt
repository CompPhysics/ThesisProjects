This IPython notebook ManyBodyMethods.ipynb does not require any additional
programs.

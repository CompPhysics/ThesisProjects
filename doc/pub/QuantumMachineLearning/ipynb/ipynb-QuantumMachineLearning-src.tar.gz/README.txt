This IPython notebook QuantumMachineLearning.ipynb does not require any additional
programs.

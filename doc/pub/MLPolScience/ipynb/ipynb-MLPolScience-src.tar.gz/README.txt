This IPython notebook MLPolScience.ipynb does not require any additional
programs.

This IPython notebook Boltzmann.ipynb does not require any additional
programs.

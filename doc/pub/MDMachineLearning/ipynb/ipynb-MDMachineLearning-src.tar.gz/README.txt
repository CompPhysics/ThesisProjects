This IPython notebook MDMachineLearning.ipynb does not require any additional
programs.

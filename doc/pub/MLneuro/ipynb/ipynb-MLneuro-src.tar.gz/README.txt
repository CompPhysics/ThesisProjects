This IPython notebook MLneuro.ipynb does not require any additional
programs.

#ifndef LIB_LIBRARY_IS_INCLUDED
#define LIB_LIBRARY_IS_INCLUDED
 
    /*
     * The definition module                              
     *                      lib.hpp                    
     * for the library function common for all C++ programs.
     */


#include "/fys/blitz-0.6/include/blitz/array."


#include <iostream>          // Standard ANSI-C++ include files
#include <new>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>

#include <time.h>
#include <ctype.h>
#include <sys/time.h>

 using namespace std;
 using namespace blitz;

#define   NULL_PTR       (void *) 0
#define   ZERO           0
#define   D_ZERO         1.0E-10
#define   UI             unsigned int

     // Function declarations 

template <typename T>        void ludcmp(T ** , int, int * , T * );
template <typename T>        void lubksb(T **, int, int *, T *);
template <typename T>        T     ran0(int&);

     /*
     ** The template function
     **           ran0()
     ** is an "Minimal" random number generator of Park and Miller
     ** (see Numerical recipe page 279). Set or reset the input value
     ** idum to any integer value (except the unlikely value MASK)
     ** to initialize the sequence; idum must not be altered between
     ** calls for sucessive deviates in a sequence.
     ** The function returns a uniform deviate between 0.0 and 1.0.
     */

template <typename T>
  T ran0(int& idum)
{
  const int      IA = 16807,  IM =  2147483647, IQ = 127773,
                 IR = 2836, MASK =  123459876;
  const T        AM = (1.0/IM);
  int            k;
  T              ans;

   idum ^= MASK;
   k     = (idum)/IQ;
   idum  = IA*(idum - k*IQ) - IR*k;
   if(idum < 0) idum += IM;
   ans   = AM*(idum);
   idum ^= MASK;
   return ans;
} // End: template function ran0() 

    /*
    ** The template function
    **       ludcmp()
    ** takes as input a BLITZ matrix Array<T,2> A() of dimension n and
    ** replaces it by the LU decomposition of a rowwise permutation of
    ** itself. The results is stored in A() in the form given by 
    ** eq. (2.3.14) in "Numerical Recipe", sect. 2.3, page 45. The vector
    ** Array<T,1> Index() records the row permutation effected by the
    ** partial pivoting;
    ** The parameter d is output as +1 or -1 depending on whether the 
    ** number of row interchanges was even or odd, respectively. This
    ** routine is used in combination with the template function lubksb()
    ** to solve linear equations or invert a matrix.
    ** The function is slightly modified from the version in Numerical
    ** recipe
    */

template <typename T>
void ludcmp(Array<T,2>& A, int n, Array<int,1>& Index, T& d)
{
   int         i, imax, j, k;
   T           big, dum, sum, temp;
   Array<T,1>  vv(n);

   d = 1.0;                              // no row interchange yet
   for(i = 0; i < n; i++) {     // loop over rows to get scaling information
      big = ZERO;
      for(j = 0; j < n; j++) {
         if((temp = fabs(A(i,j))) > big) big = temp;
      }
      if(big == ZERO) {
	cout << endl << endl
             << "Singular Array<T,2> A() in template function ludcmp()"
             << endl <<endl;
         exit(1);
      }               
      vv(i) = 1.0/big;                 // save scaling */
   } // end i-loop */

   for(j = 0; j < n; j++) {     // loop over columns of Crout's method
      for(i = 0; i < j; i++) {   // not i = j
         sum = A(i,j);    
	 for(k = 0; k < i; k++) sum -= A(i,k) * A(k,j);
	 A(i,j) = sum;
      }
      big = ZERO;   // initialization for search for largest pivot element
      for(i = j; i < n; i++) {
         sum = A(i,j);
	 for(k = 0; k < j; k++)  {
	   sum -=  A(i,k) * A(k,j);
	 }
	 A(i,j) = sum;
	 if((dum = vv(i)*fabs(sum)) >= big) {
  	    big = dum;
	    imax = i;
	 }
      } // end i-loop
      if(j != imax) {    // do we need to interchange rows ?
         for(k = 0; k< n; k++) {       // yes
	    dum        = A(imax,k);
	     A(imax,k) = A(j,k);
	     A(j,k)    = dum;
	 }
	 d *= -1;            // and change the parit of d
	 vv(imax) = vv(j);         // also interchange scaling factor 
      }
      Index(j) = imax;
      if(fabs(A(j,j)) < ZERO)  A(j,j) = ZERO;

        /*
        ** if the pivot element is zero the matrix is singular
        ** (at least to the precision of the algorithm). For 
        ** some application of singular matrices, it is desirable
        ** to substitute ZERO for zero,
        */

      if(j < (n - 1)) {                   // divide by pivot element 
         dum = 1.0/A(j,j);
	 for(i = j+1; i < n; i++) A(i,j) *= dum;
      }
   } // end j-loop over columns
  
   vv.free();   // release local memory

}  // End: template function ludcmp()
 
    /*
    ** The template function 
    **             lubksb()
    ** solves the set of linear equations 
    **           A X = B 
    ** of dimension n. Array<T,2> A() is input, not as the
    ** matrix A() but rather as its LU decomposition, 
    ** determined by the template function ludcmp(),
    ** Array<int,1> Index() is input as the permutation vector
    ** returned by ludcmp(). Array<T,1> B() is input as the
    **  right-hand side vector B,
    ** The solution X is returned in B(). The input data A(),
    ** n and Index() are not modified. This routine take into 
    ** account the possibility that B() will begin with many
    ** zero elements, so it is efficient for use in matrix
    ** inversion.
    ** The function is slightly modified from the version in 
    ** in Numerical recipe.
    */

template <typename T>
void lubksb(Array<T,2>& A, int n, Array<int,1>& Index, Array<T,1>&  B)
{
   int        i, ii = 0, ip, j;
   T          sum;

   for(i = 0; i < n; i++) {
      ip    = Index(i);
      sum   = B(ip);
      B(ip) = B(i);
      if(ii != 0) {
	for(j = ii - 1; j < i; j++) sum -= A(i,j) * B(j);
      }
      else if(sum != 0.0 )  ii = i + 1;
      B(i) = sum;
   }
   for(i = n - 1; i >= 0; i--) {
      sum = B(i);
      for(j = i+1; j < n; j++) sum -= A(i,j) * B(j);
      B(i) = sum/A(i,i);
   }
} // end: template function lubksb()


#endif



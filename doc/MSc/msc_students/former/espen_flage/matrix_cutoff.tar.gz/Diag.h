#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Diag {

 public:
  // tgli from Numerical Recipe diagonalize a trigiagonal matrix using implicit QR
  void tqli(vector<double> &,vector<double> &,vector<vector<double> > &);
  // tred2 from Numerical Recipe reduces a matrix to a tridiagonal form using Housholder reflection
  void tred2(vector<vector<double> > &,vector<double> &,vector<double> &);
  // sort_tridiag sorts the eigenvalues and eigenvectors
  void sort_tridiag(vector<double> &);
  // non_diag_matrix_elements calulates matrix values using Talmi integrals
  double perturbation_elements(int,int,int,int,vector<double> &);
  double matrix_series(int,int,int,int,int,double,vector<double> &,vector<vector<double> > &);
  // gammln from Numerical Recipe calculates the logartithm of the Gamma function
  double gammln(double);
  double factorial_true(int);
  void factorialln(vector<double> &);
  double matrix_num_int(int,int,int,int,int,double,vector<double> &,vector<vector<double> > &,vector<double> &, vector<double> &s);
  void gaulag(vector<double> &, vector<double> &, double);
  double numeric_integration_gauss(int,int,int,int,vector<double> &,vector<double> &);
  double genLaguerre(int,double,double);
  double func(int,int,int,double);
  double pythag(double,double);
};

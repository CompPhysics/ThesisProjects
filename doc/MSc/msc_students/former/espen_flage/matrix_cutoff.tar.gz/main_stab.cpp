#include "Diag.h"

// main
int main (int argc, const char* argv[]) {

  // initialize
  Diag myDiag;
  
  // Define input parameters
  int N;
  int L_or_M;
  int l_or_m;
  int n_mark_max;
  double factor;
  int dim;
  // ask user
  cout << "What dimension? [3=3D, 2=2D]" << endl;
  cin >> dim;
  if (dim==2) {
    cout << "Input 'N[int] M[int] m[int] n_mark_max[int] factor[double]'" << endl;
  }
  else {
    cout << "Input 'N[int] L[int] l[int] n_mark_max[int] factor[double]'" << endl;
  }
    cin >> N >> L_or_M >> l_or_m >> n_mark_max >> factor;
    cout << endl;
    cout << "Starting diagonalization using numerical integration for" << endl;
  cout << "----------------------------------------------------" << endl;
  cout << "|N=" << N << "  |L_or_M=" << L_or_M << "  |l_or_m=" << l_or_m << "  |n_mark_max=" << n_mark_max << "   |l_0/a_0=" << factor << "      | " << endl;
  cout << "----------------------------------------------------" << endl;

    
    
  // Check if n_mark_max=0. This give error in tred2.
  if (n_mark_max==0) {
    cout << "Syntax error!" << endl;
    cout << "n_mark_max need to be greater than zero" << endl;
    exit(1);
  }

  double dim_value=1.5;
  
  ofstream outFile("dump");

  int p=2;
  int p_step=1;
  int factorial_max;
  vector<double> old_d;
  vector<double> d(1);
  vector<double> e(1);
  vector<double> weights(100);
  vector<double> points(100);

  if (dim==2) {
    factorial_max=(n_mark_max+abs(l_or_m))+1;
    dim_value=1.0;
    myDiag.gaulag(points,weights,(abs(l_or_m)-0.5));
  }
  else {
    factorial_max=2*(n_mark_max+abs(l_or_m))+2;
    myDiag.gaulag(points,weights,(double)l_or_m);  
  }
  
  vector<double> factorialln(factorial_max+1); 
  myDiag.factorialln(factorialln);

  while (p<=n_mark_max) {
    // denne er MEGET fishy!
    vector<vector<double> > eigen(p+1,vector<double>(p+1));
    d.resize(p+1);
    e.resize(p+1);
    d.empty();
    e.empty();
    
    // fill the matrix
    myDiag.matrix_num_int(N,abs(L_or_M),abs(l_or_m),p,dim,factor,factorialln,eigen,points,weights);
    
    // diagonalize
    myDiag.tred2(eigen,d,e);
    myDiag.tqli(d,e,eigen);
    myDiag.sort_tridiag(d);

    if (p>2) {
      outFile << p;
      outFile.put(' ');
      for (int i=1; i<=p-p_step; i++) {
	outFile << fabs(old_d[i]-d[i]);
	outFile.put(' ');
      }
    }
    outFile << endl;
    old_d=d;
    p=p+p_step;
  }
  outFile.close();
  return 0;
}

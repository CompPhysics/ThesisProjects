#include "Solver.h"
#include "arpack++/arssym.h"
#include "arpack++/arbssym.h"

FDM::FDM(int num_points, double step){
  h=step;
  N=num_points-2;
  potential=new double[N];
  bm = matrix(N,N,0);
}

FDM::~FDM(){delete[] potential;}

void FDM::set_potential(int dim, int qn, double omega2, double K){ 
  double h4=h*h*h*h;
  double nabla;
  double h2=h*h;

  if(dim==2) nabla=qn*qn-0.25;
  else if(dim==3) nabla=qn*(qn+1);
  else{ nabla=0; cout << "error in set_potential!"<<endl;}

  for(int i=1; i<=N; i++)
    potential[i-1]=nabla/(i*i)+omega2*i*i*h4+ K*h/i;
}


void FDM::make_system(){
  for(int i=2; i<N; i++){
    bm[i-1][i-1]=2 +potential[i-1]; 
    bm[i-1][i]=bm[i-1][i-2]=-1;
  }
  bm[0][0]=2 +potential[0];
  bm[N-1][N-1]=2 +potential[N-1];
  bm[0][1]= bm[N-1][N-2]=-1;
}
void FDM::solve_system(int nev, bool vectors){
  double h2=h*h;
  double* temp=new double[N];
  int nconv; 

  double* a_array=bm.get_array_symb(N, 2);
  ARbdSymMatrix<double> amat(N, 1, a_array);

  double* resid=new double[N];
  for(int i=0; i<N; i++) resid[i]=1;

  if(nev>N) nev=N;
  if(nev>N-1){
    int nev1=nev/2;
    int nconv1;
    ARluSymStdEig<double > eigensolver1(nev1, amat,  "SM", 0, 0.0, 0, resid , true); 
    ARluSymStdEig<double > eigensolver2(nev-nev1, amat,  "LM", 0, 0.0, 0, resid , true);

    if(vectors){
      nconv1 = eigensolver1.FindEigenvectors();
      for(int i=0; i<N; i++) resid[i]=1;
      nconv = eigensolver2.FindEigenvectors();
      solution=Eigenstates(nev,N,h);

      for(int i=0; i<nconv1; i++){
	for(int j=0; j<N; j++)  {
	  temp[j]=eigensolver1.Eigenvector(i,j);
	}
	solution.add_pair(i, eigensolver1.Eigenvalue(i)/h2, temp);
      }  
      for(int i=0; i<nconv; i++){
	for(int j=0; j<N; j++) {

	  temp[j]=eigensolver2.Eigenvector(i,j);
	}
	solution.add_pair(i+nconv1, eigensolver2.Eigenvalue(i)/h2, temp); 
      }  
    }else{
      nconv1 = eigensolver1.FindEigenvalues();
      for(int i=0; i<N; i++) resid[i]=1;
      nconv = eigensolver2.FindEigenvalues();
      solution=Eigenstates(nev,0,h); 
      for(int i=0; i<nconv1; i++) solution.eigenvalue[i]=eigensolver1.Eigenvalue(nconv1-1-i)/h2;
      for(int i=0; i<nconv; i++) solution.eigenvalue[i+nconv1]=eigensolver2.Eigenvalue(i)/h2;
    }
  }else{
    ARluSymStdEig<double> eigensolver(nev, amat, "SM", 0, 0.0, 0, resid , true); 
    if(vectors){
      
      nconv = eigensolver.FindEigenvectors();
      solution=Eigenstates(nconv,N,h); 
      for(int i=0; i<nconv; i++){
	for(int j=0; j<N; j++)  temp[j]=eigensolver.Eigenvector(i,j);
	solution.add_pair(i, eigensolver.Eigenvalue(i)/h2, temp);
      }
      
    }else{
      nconv = eigensolver.FindEigenvalues();
      solution=Eigenstates(nconv,0,h); 
      for(int i=0; i<nconv; i++) solution.eigenvalue[i]=eigensolver.Eigenvalue(nconv-1-i)/h2;
    }
    if(nconv<nev) {
      cout << "Increase number of eigenvalues in search for arpack..."<<endl;
      solve_system(nev+10, vectors);
    }
  }

  delete[] resid;
  delete[] temp;
  delete[] a_array;
}

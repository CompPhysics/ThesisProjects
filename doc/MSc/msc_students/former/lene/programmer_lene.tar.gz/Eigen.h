#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

class Eigenstates{

 public:
  int number; //number of eigenstates
  int length; //length of eigenvectors
  double step_length; //even step_length

  //quantum numbers?
  int* n;

  double* eigenvalue;
  double** eigenvector;

  void allocate(int N, int l, double h){
    number=N;
    length=l;
    step_length=h;
   
    n=new int[number];
    eigenvalue=new double[number];
    eigenvector=new double*[number];
    for(int i=0; i<number; i++) {
      eigenvector[i]=new double[length];
    }
  }

  void deallocate(){
    for(int i=0; i<number; i++) {
      delete[] eigenvector[i];
    }
    delete[] eigenvalue;
    delete[] eigenvector;
    delete[] n;
   }

  Eigenstates(){ allocate(1,1,1.0); } 
  Eigenstates(int N, int l, double h){ allocate(N,l,h); }
  Eigenstates(const Eigenstates &in){
    allocate(in.number, in.length, in.step_length);
    for(int i=0; i<number; i++){
      eigenvalue[i]=in.eigenvalue[i];
      for(int j=0; j<length; j++) eigenvector[i][j]=in.eigenvector[i][j];
    }
  }

  ~Eigenstates(){deallocate();}

  Eigenstates& operator=(const Eigenstates& in){
    if (this != &in){
      if(number!=in.number || length!=in.length){
	deallocate();
	allocate(in.number, in.length, in.step_length);
      }
      for(int i=0; i<number; i++){
	eigenvalue[i]=in.eigenvalue[i];
	for(int j=0; j<length; j++) eigenvector[i][j]=in.eigenvector[i][j];
      }
    }
    return *this;
  }

  void find_zeros(){
    int zeros;
    for(int i=0; i<number; i++){
      zeros=0;
      for(int j=1; j<length; j++){
	if((abs(eigenvector[i][j]-eigenvector[i][j-1])>10e-8) && ((eigenvector[i][j-1] >0 && eigenvector[i][j]<0) || (eigenvector[i][j-1] <0 && eigenvector[i][j]>0))  ){
	  zeros++;
	}
      }
      n[i]=zeros;
    }
  }

  //add an eigenstate to the set
  void add_pair(int k, double val, double* vec){
    //assumes k<number, vec[l]
    for(int i=0; i<length; i++){
      eigenvector[k][i]=vec[i];
    }
    eigenvalue[k]=val;
  }

  //print eigenvalues to screen
  void show_eigenvalues(){
    show_eigenvalues(1);
  }

  //print eigenvalues scaled by omega to screen
  void show_eigenvalues(double omega){
    if (omega==0) omega=1;
    cout << "Eigenvalues: " <<endl;
    for(int i=0; i<number; i++){
      cout << eigenvalue[i]/omega << endl;
  }
    cout << "---------------" <<endl;  
  }

  //prints eigenvectors to screen, only useful for a small set!
  void print_eigenvectors(){
    cout << "Eigenvectors" <<endl;
    for(int i=0; i<number; i++){
      for(int j=0; j<length; j++){
	cout <<eigenvector[i][j] << "     "; 
      }
      cout << endl <<endl;
    }
    cout << "---------------" <<endl;
  }

  //prints the set to a matlab script
  void print(char * filein, int m, int l, double omega){
    char* ext = ".m";
    char file[80];
    strcpy(file, filein);
    strcat(file, ext);

    ofstream ofile;
    ofile.open (file);
    ofile << "m = " << m << ";" << endl;
    ofile << "l = " << l << ";" << endl;
    ofile << "omega = " << omega << ";" << endl;
    ofile << "h = " << step_length << ";" << endl; 
    ofile << "E = [ " ;
    for(int i=0; i<number; i++) ofile << scientific << setprecision(21) << setw(28)  << eigenvalue[i];
    ofile << "];" << endl;

    ofile << "V = [ " <<endl;
    for(int j=0; j<length; j++){
      for(int i=0; i<number; i++) ofile << scientific <<setprecision(21) << setw(30) <<  eigenvector[i][j];
      ofile << endl;
    }
    ofile << "];" << endl;
    ofile.close();
  }

  //shift all eigenvalues: val=val+shift
  void shift(double shift){
    for(int i=0; i<number; i++){ 
      eigenvalue[i] += shift;
    }  
  }

  //scale all eigenvalues: val=val*scale
  void scale(double scale){
    for(int i=0; i<number; i++){ 
      eigenvalue[i] *= scale;
    }  
  }

  //shift and scale all eigenvalues val=val*scale+shift
  void scale_shift(double scale, double shift){
    for(int i=0; i<number; i++){ 
      eigenvalue[i] = scale*eigenvalue[i]+shift;
    }  
  }

  //dot product eigenvector(i)*eigenvector(j)
  double dot(int i, int j){ // legge til dim + r senere
   double prod=0;

   for(int k=0; k<length; k++){ //u_0, u_N = 0
     prod+=eigenvector[i][k]*eigenvector[j][k]; 
   }
   prod*=step_length;
   return prod;
 }

  //normalise eigenvector(i)
  void normalise_vec(int i){
   double norm=sqrt(dot(i,i));
   for(int j=0; j<length; j++){
     eigenvector[i][j]=eigenvector[i][j]/norm;
   } 
  }
  
  //normalise all eigenvectors
  void normalise(){
    for(int i=0; i<number; i++){
      normalise_vec(i);
    }
  }

  //use the basis of eigenvectors to create an orthogonal set
  void orthogonalise_set(){
    double d;
    normalise_vec(0);
    for(int i=1; i<number; i++){
      for(int j=0; j<i; j++){
	d=dot(i,j);
	for(int k=0; k<length; k++){
	  eigenvector[i][k]-=d*eigenvector[j][k];
	}
	normalise_vec(i);
      }
    }
  }

  //compare the n_compare first eigenvalues to set b, returning sum|a_i-b_i|, used i rm_loop i quantumdot.cpp, compare algo may be improved to check the convergence of eigenvalue(n_compare)
  double compare_set(Eigenstates b, int n_compare){
    double error=0;
    n_compare = min(min(n_compare, number), b.number);
    for(int i=0; i<n_compare; i++){
      error+=abs(eigenvalue[i]-b.eigenvalue[i]);
    }
    return error;
  }

};

#include <cmath>
#include <iostream>
#include <iomanip>
#include <fstream>
#include "Eigen.h" 
#include "matrix.h"
#include "arpack++/arbsmat.h"
using namespace std;

class Solver{

 public: 
  int N; //size of global matrix
  double h; //step_length/element size
  Eigenstates solution; //solution
  
 public:  

  void virtual solve(int, bool){};
  void virtual set_potential(int, int, double, double){};
  virtual ~Solver(){}
};

class FDM : public Solver {

 public:

  matrix bm;
  FDM(double h, double min, double max);
  FDM(int N, double h);
  ~FDM();

  void solve(int nev, bool vectors){make_system(); solve_system(nev, vectors);};
  void make_system();
  void solve_system(int, bool);

  void set_potential(int, int, double, double);
  void matvec_product(double *, double*);

 private:
  double* potential;

 };

class FEM : public Solver { 

 public:
  int M; //number of elements
  int n_e; //number of nodes per element
  int int_N; //number of integration points

  matrix left;
  matrix right;

  matrix potential;
  double x_min;

  double* xi;
  double* weights;

  FEM(){};
  ~FEM(){delete[] xi; delete[] weights; };
  FEM(int elements, int local, int int_N, double h);


  void solve(int nev, bool vectors){make_system(); solve_system(nev, vectors);};
  double N_i(int, double);
  double dN_i(int, double);

  double integrate(double*);
  void calc_element(int e, matrix &left, matrix &right);
  void set_integration_points();

  void set_potential(int dim, int qn, double omega2, double K, double x_min);
  void test1D(double);
  void make_system();
  void solve_system(int, bool);
  void bc(); 

};

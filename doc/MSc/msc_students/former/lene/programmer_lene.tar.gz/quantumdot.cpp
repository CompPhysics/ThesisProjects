#include "FEM.h"
#include "ConfigFile.h"
#include <string>

class quantumdot{ 

private: 
  int M; //Number of elements
  int N; //Number of nodes
  double h; //FEM: size of element, FDM: distance between nodes
  bool full_set; //are we searching for a full set eigenstates
  int n_eigenvalues; //number of eigenvalues to be found
  int n_compare;

  int m, l; //quantum numbers
  double omega_0, omega2, omega; //oscillator frequency
  double B; //magnetic field
  double K; //interaction term: K=1 for relative equation

  int dim; //specify 2D or 3D problem
  int type; //specify FDM=1 or FEM=2
  int problem; //specify which general problem to be solved !!!

  double r_min; 
  double r_max;

  Eigenstates solution; //final solution is stored

  int n_richardson; //order of the Richardson extrapolation
  int max_iterations; //maximum number of iterations in rmax

  int n_e, n_int; //number of nodes per element and integration points for FEM

  char* path;
  char file[80];
  char run[5];

public:
  quantumdot(){
    initialise(); //read input from file and set variables

    //loop over increasing r_max values
    rm_loop(0.0001, max_iterations); 
    solution.scale_shift(0.5, -0.5*B*m); //calculates E= 0.5eps-0.5Bm

    output_filename();
    single_latex(file); 
 
    if(K==0.0) {
      eigenvalue_report(); 
    }
    else {
      solution.show_eigenvalues();    
    }

    solution.orthogonalise_set(); //orthogonalise eigenvectors
    solution.print(file, m, l, omega); //print eigenstates to matlab file file.m
  }

private:
  //simple FEM solver
  Eigenstates FEMsolve(bool vec){
    cout << "FEM: " <<  "r_max = " << r_max << " , M = " << M <<", h = " << h <<endl;
    FEM x(M,n_e,n_int,h);

    if(dim==2) x.set_potential(2,m,omega2,K, r_min);
    else if(dim==3) x.set_potential(3,l,omega2,K, r_min);
    x.solve(n_eigenvalues, vec );
    return x.solution;
  }

  //simple FDM solver
  Eigenstates FDMsolve(bool vec){
    cout << "FDM: " <<  "r_max = " << r_max << " , N = " << M+1 << ", h = " << h <<endl;
    FDM x(M+1,h);
    
    if(dim==2) x.set_potential(2,m,omega2,K);
    else if(dim==3) x.set_potential(3,l,omega2,K);
    x.solve(n_eigenvalues, vec);
    return x.solution;
  }

  //print a set of eigenvalues, comparing the to analytic  solutions
  void eigenvalue_report(){ //assumes K=0!
    double analytic;
    double numeric;
    double mag = 0.5*B*m;
    double num;
    if(dim==2) num=abs(m)+1;
    else if(dim==3) num=l+1.5;

    cout << "Numerical solution  " << "Analytic solution  " << "Relative error |a-n|/a" <<endl;
    if(omega==0) omega=1;
    for(int i=0; i<n_eigenvalues; i++){
      numeric=solution.eigenvalue[i];
      analytic=num*omega-mag;
      cout << fixed << setw(15) << setprecision(8) << numeric;
      cout << setw(15) << analytic;
      cout << scientific << setw(30) << setprecision(8) << abs(analytic-numeric)/analytic;
      cout << endl;
      num+=2;
    }
    cout << "---------------" <<endl; 
  }

  //print a set of eigenvalues, comparing the to analytic  solutions to file.tex
  void single_latex(char* filein){    
    char* ext = ".tex";
    char file[80];
    strcpy(file, filein);
    strcat(file, ext);

    double analytic;
    double numeric;
    double mag = 0.5*B*m;
    double num;
    if(dim==2) num=abs(m)+1;
    else if(dim==3) num=l+1.5;
    //if(omega==0) omega=1; //fjern denne senere

    ofstream ofile;
    ofile.open (file);
    ofile << "\\begin{table}[hbp]" <<endl;
    ofile << "\\centering" << endl;
    ofile << "\\begin{tabular}{ccc}" << endl;
    ofile << "Numerical & Analytic & Relative error = |a-n|/a\\\\" <<endl;
    ofile << "\\hline" << endl;
    for(int i=0; i<n_eigenvalues; i++){
      numeric=solution.eigenvalue[i];
      analytic=num*omega-mag;
      ofile << setw(10) << setprecision(8) << numeric << " & ";
      ofile << setw(3)  << analytic << " & ";
      ofile << scientific << setw(16) << setprecision(8) << abs(analytic-numeric)/analytic;
      ofile << " \\\\ " <<endl;
      ofile.unsetf ( ios_base::scientific );
      num+=2;
    }
    ofile << "\\end{tabular}" <<endl;
    ofile << "\\caption{ " << "m=" << m << ", h=" << h << ", $r_{max}$=" << r_max;
    if(type==1) ofile << " ,FDM, rich = " << n_richardson;
    else ofile <<" ,FEM, $n_e$=" << n_e << ", $n_{int}$= " << n_int;
    ofile <<"}" <<endl;
    ofile << "\\label{}" <<endl;
    ofile << "\\end{table}" <<endl;
    ofile.close();
  }
  
  //read input from file using configuration manager: http://www-personal.umich.edu/~wagnerr/ConfigFile.html
  void initialise(){
    double temp;
    ConfigFile config( "qd.inp");
    config.readInto( temp, "omegainv", 0.0);
    if(temp!=0) omega_0=1.0/temp;
    else config.readInto( omega_0, "omega", 1.0);
    config.readInto( B, "B", 0.0);
    config.readInto( m, "m", 1); 
    config.readInto( l, "l", 1);
    config.readInto( K, "K", 0.0); 
    config.readInto( h, "h", .1);
    config.readInto( max_iterations, "maxit", 10);

    //read r_max from file or calculate, set M
    config.readInto( r_min, "r_min", 0.0);
    config.readInto( r_max, "r_max", 0.0);
    if(r_max==0.0) r_max=init_rmax(omega);
    M=(int)ceil(r_max/h);

    config.readInto( dim, "dim", 2);
    if(dim!=3) dim =2;
    cout << dim <<endl;
    config.readInto( type, "type", 2); 
    if(type==2){
      config.readInto( n_e, "n_e", 2); 
      if(n_e>3) n_e=3;
      config.readInto( n_int, "n_int", 5); 
      N=M*(n_e-1)+1;
    }
    else {
      type=1;
      config.readInto(n_richardson, "rich", 0); 
      N=M+1;
    }

    //change constants for problem type
    config.readInto( problem, "problem", 0); 
    if(problem==2) relative();
    else if(problem==3) com();
    else if(problem==1) single();
    else problem=0;

    //include the magnetic field in omega
    omega2=omega_0*omega_0+0.25*B*B;
    omega=sqrt(omega2);

    config.readInto(full_set, "all" , false);
    if(!full_set) config.readInto( n_eigenvalues, "num_eigenvalues", 10);
    if(full_set) n_eigenvalues=N-2; 
    config.readInto( n_compare, "num_eigenvalues", 10);
    

    //Output info to screen
    cout << "Solving: -u'' + ";
    if(dim==3) cout << "l(l+1)";
    else cout << "(m^2-0.25)";
    cout << "u/r^2 + w^2r^2u";
    if(K!=0.0) cout << "+" << K << " u/r = eps u";
    cout << " = eps u";
    cout <<endl << "w = " << omega_0 << ", B = " << B;
    if(dim==3) cout << " ,l = " << l;
    cout << " ,m = " << m <<endl << "Using ";
    if(type==1) cout << "FDM, with step length h = " << h << " Richardson extrapolation order = " << n_richardson <<endl;
    else cout <<"FEM, with element size h = " << h << ", using " << n_e << " nodes per element and " << n_int << " integration points"<<endl;
       
  }

  //set up output file
  void output_filename(){
    path= "../Tekst/Double/";//3d/";
    strcpy(file, path);
    
 //    strcat(file, "r");
//     sprintf(run, "%04.0f" ,r_max);
//     strcat(file, run);
//     strcat(file, "w");
//     sprintf(run, "%g" ,omega);
//     strcat(file, run);

//     strcat(file, "h");
//     sprintf(run, "%g" ,h);
//     strcat(file, run);
    strcat(file, "B");
    sprintf(run, "%g" ,B);
    strcat(file, run);
//     strcat(file, "m");
//     sprintf(run, "%i" ,m);
//     strcat(file, run);
//     strcat(file, "l");
//     sprintf(run, "%i" ,l);
//     strcat(file, run);

    if(type==1) strcat(file, "FDM");
    else {
      strcat(file, "FEM");
      sprintf(run, "%i" ,n_e);
      strcat(file, run);
    }

    cout << "Output to: " << file << endl;
  }

  //initialise r_max if not set
  int init_rmax(double omega){
    double epsilon=0.001;
    if(omega==0) return (int)-log(epsilon)+1; 
    else return (int)ceil(sqrt(-2* log(epsilon)/omega));
  }

  //change variables according to problem
  void relative(){ K=1; omega_0*=0.5; }
  void com(){ K=0; omega_0*=2; }
  void single(){ K=0;}

  //solve for increasing r_max until the a stopping criterea is reached
  //the Eigenvalues and Eigenvector of the final r_max is stored
  void rm_loop(double limit, int max_iterations){ 
        
    Eigenstates temp;
    int count=0;
    double diff=1;
    if(max_iterations>0){
      cout <<endl<< "Starting loop over rmax" << endl;
      if(type==1) {
	if(n_richardson==0) solution=FDMsolve(false);
	else solution=Richardson(n_richardson, false);
      }
      if(type==2) solution=FEMsolve(false);
    }
    while(diff>limit && count<max_iterations){ 

      r_max++;
      M=(int)ceil(r_max/h);
      if(full_set) n_eigenvalues=N-2; //pass p� for ne!!!

      if(type==1) {
	if(n_richardson==0) temp=FDMsolve(false);
	else temp=Richardson(n_richardson, false);
      }
      if(type==2) temp=FEMsolve(false);

      diff=solution.compare_set(temp, n_compare);
      cout << "Difference in set =  " << diff << endl;
      solution=temp;
      count++;   
    }
    cout << "Done looping over rmax -> rmax = " << r_max << endl << endl;
    if(max_iterations>0 && count == max_iterations) cout << "Reached the maximum number of iterations in r_max." << endl;
    
    if(type==1) {
      if(n_richardson==0) solution=FDMsolve(true);
      else solution=Richardson(n_richardson, true);
    }
    if(type==2) solution=FEMsolve(true);

  }

  //Richardson extrapolations
  Eigenstates Richardson(int R_it, bool vec){
    
    cout << "Richardsom Iteration " << 0 << ": ";
      //cout << solution.step_length;
    Eigenstates* saved=new Eigenstates[R_it+1];
    saved[0]=FDMsolve(vec);

    Eigenstates temp;
    Eigenstates next;

    for(int i=0; i<R_it; i++){
      h*=0.5;
      M=(int)ceil(r_max/h);
      cout << "R Iteration " << i+1 << ": ";

      temp=FDMsolve(vec);
      next=Rich(1, temp, saved[0]); 
      saved[0]=temp;

      for(int j=1; j<=i; j++){
	temp=next;
	next=Rich(j+1, temp, saved[j]);
	saved[j]=temp;
	
      }
      
      saved[i+1]=next;
      
    }
    h*=pow(2.0,R_it);
    M=(int)ceil(r_max/h);
    //the last calculated eigenvectors are stored in saved[0], the most accurate eigenvalues are stored in saved[0], so we copy and return this as a set
    
    Eigenstates final;
    final=saved[0];

    for(int i=0; i<n_eigenvalues; i++) final.eigenvalue[i]=saved[R_it].eigenvalue[i];

    delete[] saved; 
    return final; 
  }

  Eigenstates Rich(int j, Eigenstates a, Eigenstates b){
    Eigenstates out(n_eigenvalues, 0 ,1);
    for(int i=0; i<n_eigenvalues; i++){
      out.eigenvalue[i]=(pow(4.0, j)*a.eigenvalue[i]-b.eigenvalue[i])/(pow(4.0,j)-1);
    }
    return out;
  }

};

int main(int argc, char** args){
  quantumdot qd;
}



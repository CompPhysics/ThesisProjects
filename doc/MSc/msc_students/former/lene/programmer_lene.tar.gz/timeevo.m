clear
%fortegnsproblemer - ved superposisjon

%read
eigenset;
[l n]=size(V);
D=diag(E);
I=eye(l);
T=20;
t=0;
dt=0.25;
steps=T/dt;
W=1;
%wf=2;
f=1*2*pi/T;

r = linspace(h, l*h , l);

d=zeros(l,1); 
%d(wf)=1; %velge hvilken tilstand vi starter i
d(1)=1;
d(6)=1;
d(4)=1;
d=d/norm(d);

d0=d;
c=V*d;
p=conj(c).*c;
a=d0;

%plot analytic for W=0 --
figure(2)
plot(r,real(c),'b') %real part
hold on
plot(r,imag(c),'r') %imaginary part

plot(r,real(a),'b--')
plot(r,imag(a),'r--')

plot(r, p, 'g') % c*c
ylim([-1,1]);
hold off
Movie(1)=getframe;

for j=0:steps-1 %evolve from tj to tj+1
    
   %H(s)
   int1=D*dt+I*-W*(cos(f*(t+dt))-cos(f*t))/f;
   %sH(s)
   int2=D*dt*(t+0.5*dt)+I*W*(sin(f*(t+dt))-t*f*cos(f*(t+dt))-sin(f*dt)+t*f*cos(f*dt))/f/f;

   H0=-i*int1;
   H1=i/dt*((t+0.5*dt)*int1-int2);

   d=expv(-1, H1, d);
   d=expv(1, H0, d);
   d=expv(1, H1, d);

   t=t+dt;
   c=V*d;
   p=conj(c).*c;

   a=V*diag(exp(-i*E*t))*d0;
   diff=c-a;
   sum(diff); %sammenlikne med analytisk for W=0
   
   plot(r,real(c), 'b')
   hold on
   plot(r,imag(c),'r')
   plot(r,real(a),'b--')
   %hold on
   plot(r,imag(a),'r--')   
   plot(r, p, 'g')
   text(10*h, 0.8, ['t=', num2str(t)])
   hold off
   ylim([-1,1]);
   Movie(j+2)=getframe;
   %sin(f*t)

end


%movie(Movie,1,1)

/* #include<iostream> */
/* #include<cmath> */

#include "Solver.h"
/* using namespace std; */

/* class FEM : public Solver {  */

/*  public: */
/*   int M; //number of elements */
/*   int n_e; //number of nodes per element */
/*   int int_N; //number of integration points */

/*   matrix mat; */
/*   matrix vec; */

/*   //andre variable som brukes mange ganger */
/*   matrix x; //endre navn til x, Har: noder: x_e[N], uttrykk for x(r): x_e(xi)=x[M][int_N] */
/*   matrix potential; */
/*   double x_min; */

/*   double* xi; */
/*   double* weights; */
/*   int dim; */

/*   FEM(){}; */
/*   ~FEM(){delete[] xi; delete[] weights; }; //destruerer ikke eig + solve sys */
/*   FEM(int elements, int local, int int_N, double h); */
/*   //kopifunksjoner?? */

/*   void solve(int nev, bool vectors){make_system(); solve_system(nev, vectors);}; */
/*   double N_i(int, double); */
/*   double dN_i(int, double); */

/*   double integrate(double*); */
/*   void calc_element(int e, matrix &left, matrix &right); */
/*   void set_integration_points(); */
/*   // void gen_eigen(matrix, matrix, double*); */

/*   void set_potential(int dim, int qn, double omega2, double K, double x_min); */
/*   void test1D(double); */
/*   void make_system(); */
/*   void solve_system(int, bool); */
/*   void bc();  */

/* }; */

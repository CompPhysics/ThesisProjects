#include <iostream>
#include <iomanip>
using namespace std;

class matrix{

public:
  int rows;
  int cols;
  double** mat;

  matrix(int N, int M){allocate(N,M);}
  matrix(int N, int M, double val){
    allocate(N,M);
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
	mat[i][j]=val;
      }
    }
  }
  matrix(int N){allocate(N,N);}
  matrix(){ rows=0; cols=0;}
  virtual ~matrix(){deallocate(); }

  double* operator[](int i) const{return mat[i];}
 
  void allocate(int N, int M){
    rows=N;
    cols=M;
    mat=new double*[rows];
    for(int i=0; i<rows; i++){
      mat[i]=new double[cols];
      for(int j=0; j<cols; j++) mat[i][j]=0;
    }
  }

  void deallocate(){
    for(int i=0; i<rows; i++){
       delete[] mat[i]; 
    }
    if(rows>0)
      delete[] mat;
  }

  matrix(const matrix &in){
    allocate(in.rows, in.cols);
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
	mat[i][j]=in[i][j];
      }
    }
  }

  matrix& operator=(const matrix &in){
    deallocate();
    allocate(in.rows, in.cols);
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
	mat[i][j]=in[i][j];
      }
    }
    return *this;
  }

  void print(){ //cout
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
	cout << setw(8) << setprecision(3) << mat[i][j];
      }
      cout <<endl;
    }
  }

  void matvec(double* in, double* out){
        for(int i=0; i<rows; i++){
	  out[i]=0;
	  for(int j=0; j<cols; j++) out[i]+=mat[i][j]*in[j];
	}
  }
  

  double* get_array_symb(int size, int bands){ //som symmetrisk, bands= diag + upper
     double* array= new double[size*bands];
     for(int i=0; i<size; i++){
      for(int j=i; j<(i+bands); j++){
	array[i*(bands-1)+j] = mat[i][j]; //fyller litt utenfor, men det er ikke minneproblemer
      }
    }
     return array;
  }

  void remove(int pos){ //removes column/row pos
    double** copy=new double*[rows-1];
    for(int i=0; i<rows-1; i++) copy[i]=new double[cols-1];
    for(int i=0; i<pos; i++){
      for(int j=0; j<pos; j++) copy[i][j]=mat[i][j];
      for(int j=pos+1; j<cols; j++) copy[i][j-1]=mat[i][j];
    }
    for(int i=pos+1; i<rows; i++){
      for(int j=0; j<pos; j++) copy[i-1][j]=mat[i][j];
      for(int j=pos+1; j<cols; j++) copy[i-1][j-1]=mat[i][j];
    }
    mat=copy;
    rows--;
    cols--;
  }

};

%plots 3 eigenfunctions compared to analytic solutions for the 2D harmonic
%oscillator
% fortegnsproblemer?
clear

%read
cd ../Tekst/Single
%cd ../Tekst/Double
m1FEM3
cd ../../programmer
[l n]=size(V);
m=abs(m);

%for plotting
r = linspace(0, (l+1)*h , l+2); 
y=omega*r.*r;
zero=zeros(1,n);
V2=[zero; V; zero];
f=r.^(m+0.5).*exp(-0.5*y).*omega^(0.5*m+0.5);

%plots
figure(1)
g=sqrt(2/(factorial(m)))*f; %n=0
plot(r, g, 'r')
hold on
plot(r, V2(:,1))

g=-sqrt(2/(factorial(m+1)))*f.*(1+m-y);
plot(r, g, 'r--')
plot(r, V2(:,2), 'b--') 

g=sqrt(4/(factorial(m+2)))*f.*(0.5*y.*y-(m+2)*y+0.5*(m+1)*(m+2));
plot(r, g, 'r:')
plot(r, V2(:,3), 'b:')


g=-sqrt(12/(factorial(m+3)))*f.*(-y.*y.*y+3*(abs(m)+3)*y.*y-3*(abs(m)+3)*(abs(m)+2).*y+(abs(m)+1)*(abs(m)+2)*(abs(m)+3))/6;
plot(r, g, 'r-.')
plot(r, V2(:,4), 'b-.')



title(['Wave functions for m = ',num2str(m)])
xlabel('r [a_0]')
ylabel('u(r)')

legend('analytic n=0', 'numerical n=0', 'analytic n=1', 'numerical n=1', 'analytic n=2', 'numerical n=2', 'analytic n=3', 'numerical n=3')



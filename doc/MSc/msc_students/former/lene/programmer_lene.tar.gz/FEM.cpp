#include "Solver.h"
#include "arpack++/argsym.h"
#include "arpack++/arbgsym.h"

FEM::FEM(int elements, int local, int int_N_in, double step_length){ 

  n_e=local;
  if(n_e>3) n_e=3;
  else if(n_e<2) n_e=2;
  int_N=5;
  //int_N=int_N_in;
  //if(int_N!=2 || int_N!=4 || int_N!=5) int_N=5;

  M=elements;
  N=M*(n_e-1)+1;
  h=step_length;

  left=matrix(N,N,0); 
  right=matrix(N,N,0); 

  weights=new double[int_N];
  xi=new double[int_N];
  
  set_integration_points();
  potential=matrix(N,N,0); 
  }


void FEM::set_potential(int dim, int qn, double omega2, double K, double x_min){ 
  double x1, x2, nabla;
  this->x_min=x_min;
  if(dim==2) nabla=qn*qn-0.25;
  else if(dim==3) nabla=qn*(qn+1);
  else{ nabla=0; cout << "error in set_potential!"<<endl;}

  double div=n_e-1;
  for(int i=0; i<M; i++){ 
    for(int j=0; j<int_N; j++){
      x1=0;
      for(int s=0; s<n_e; s++)
	x1+=N_i(s, xi[j])*(x_min+(s/div+i)*h);
      x2=x1*x1;
      potential[i][j]=nabla/x2 + K/x1+omega2*x2;
    }
  }
}


void FEM::bc(){ //parallelisation: only boundary elements
  left.remove(N-1);
  right.remove(N-1);
  left.remove(0);
  right.remove(0);
  N-=2;
}



double FEM::N_i(int i, double x){ //basis functions
  if(n_e == 2){
    if(i==0) return 0.5-0.5*x;
    else if(i==1) return 0.5+0.5*x;
  }else if(n_e == 3){
    if(i==0) return 0.5*x*(x-1);
    else if(i==1) return 1-x*x;
    else if(i==2) return 0.5*x*(1+x);
  }  
}
double FEM::dN_i(int i, double x){ //basis functions
   if(n_e == 2){
    if(i==0) return -0.5;
    else if(i==1) return 0.5;
  }else if(n_e == 3){
    if(i==0) return x-0.5;
    else if(i==1) return -2*x;
    else if(i==2) return x+0.5;
  } 
}


void FEM::make_system(){
  matrix element_left=matrix(n_e,n_e);
  matrix element_right=matrix(n_e,n_e);

  for(int e=1; e<=M; e++){
    calc_element(e, element_left, element_right); 
     for(int i=0; i<n_e; i++){ 
      for(int j=0; j<n_e; j++){
	left[(n_e-1)*(e-1)+i][(n_e-1)*(e-1)+j]+=element_left[i][j];
	right[(n_e-1)*(e-1)+i][(n_e-1)*(e-1)+j]+=element_right[i][j];
      }
    }
  }
  bc();
}

void FEM::solve_system(int nev,  bool vectors){
  double* temp=new double[N];
  int nconv; 

  double* a_array=left.get_array_symb(N, n_e);
  double* b_array=right.get_array_symb(N, n_e);

  ARbdSymMatrix<double> amat(N, n_e-1, a_array);
  ARbdSymMatrix<double> bmat(N, n_e-1, b_array);
 
  double* resid=new double[N];
  for(int i=0; i<N; i++) resid[i]=1;

  if(nev>N) nev=N;
  if(nev>N-1){ //number of eigenvalues are higher than arpack can handle -> calculate in two calls
    int nev1=nev/2;
    int nconv1;
    ARluSymGenEig<double > eigensolver1(nev1, amat, bmat,  "SM", 0, 0.0, 0, resid , true); 
    ARluSymGenEig<double > eigensolver2(nev-nev1, amat, bmat,  "LM", 0, 0.0, 0, resid , true);

    if(vectors){
      nconv1 = eigensolver1.FindEigenvectors();
      for(int i=0; i<N; i++) resid[i]=1;
      nconv = eigensolver2.FindEigenvectors();
      solution=Eigenstates(nev,N,h/(n_e-1));

      for(int i=0; i<nconv1; i++){
	for(int j=0; j<N; j++)  {
	  temp[j]=eigensolver1.Eigenvector(i,j);
	}
	solution.add_pair(i, eigensolver1.Eigenvalue(i), temp);
      }  
      for(int i=0; i<nconv; i++){
	for(int j=0; j<N; j++) {

	  temp[j]=eigensolver2.Eigenvector(i,j);
	}
	solution.add_pair(i+nconv1, eigensolver2.Eigenvalue(i), temp);
      }  
    }else{
      nconv1 = eigensolver1.FindEigenvalues();
      for(int i=0; i<N; i++) resid[i]=1;
      nconv = eigensolver2.FindEigenvalues();
      solution=Eigenstates(nev,0,h/(n_e-1)); 
      for(int i=0; i<nconv1; i++) solution.eigenvalue[i]=eigensolver1.Eigenvalue(nconv1-1-i);
      for(int i=0; i<nconv; i++) solution.eigenvalue[i+nconv1]=eigensolver2.Eigenvalue(i);
    }
  }else{
    ARluSymGenEig<double > eigensolver(nev, amat, bmat,  "SM", 0, 0.0, 0, resid , true); 

    if(vectors){
      nconv = eigensolver.FindEigenvectors();
      solution=Eigenstates(nconv,N,h/(n_e-1)); 
      for(int i=0; i<nconv; i++){
	for(int j=0; j<N; j++)  temp[j]=eigensolver.Eigenvector(i,j);
	solution.add_pair(i, eigensolver.Eigenvalue(i), temp);
      }
      
    }else{
      nconv = eigensolver.FindEigenvalues();
      solution=Eigenstates(nconv,0,h/(n_e-1)); 
      for(int i=0; i<nconv; i++) solution.eigenvalue[i]=eigensolver.Eigenvalue(nconv-1-i);
    }
    if(nconv<nev) {
      cout << "nconv<num"<<endl;
      solve_system(nev+10, vectors);
    }
  }

  delete[] resid;
  delete[] temp;
  delete[] a_array;
  delete[] b_array;
}

double FEM::integrate(double* func){ 
  double sum=0;
  for(int i=0; i<int_N; i++){
    sum+=weights[i]*func[i];
  }
  return sum;
}

void FEM::calc_element(int e, matrix &eleft, matrix &eright){ 
  double* int1=new double[int_N];
  double* int2=new double[int_N];
  double M_ij;
  double xp;

  for(int i=0; i<n_e; i++){
    for(int j=0; j<n_e; j++){
      for(int k=0; k<int_N; k++){
	M_ij=h/2.0*N_i(i,xi[k])*N_i(j,xi[k]);
	int1[k]=M_ij*potential[e-1][k]+ 2.0/h*dN_i(i,xi[k])*dN_i(j,xi[k]);;
	int2[k]=M_ij;
      }
      eleft[i][j]=integrate(int1);
      eright[i][j]=integrate(int2);
    }
  }

  delete[] int1;
  delete[] int2;
}


void FEM::set_integration_points(){
  //http://mathworld.wolfram.com/Legendre-GaussQuadrature.html
  if(int_N==2){
    xi[0] = -sqrt(1.0/3.0);
    weights[0]= 1;
    xi[1]=-xi[0];
    weights[1]=1;    
  }
  else if(int_N==4){ 
    //gauss-legendre for polynomial of 4th order
    xi[0]= -sqrt(525+70*sqrt(30))/35.0;
    weights[0]= (18-sqrt(30))/36.0;
    xi[1]=-sqrt(525-70*sqrt(30))/35.0;
    weights[1]=(18+sqrt(30))/36.0;
    xi[2]=-xi[1];
    weights[2]=weights[1];
    xi[3]=-xi[0];
    weights[3]=weights[0];
  }else{ //if(int_N==5){
    //gauss-legendre for polynomial of 5th order
    xi[0]=-sqrt(245+14*sqrt(70))/21.0;
    weights[0]=(322.0-13*sqrt(70))/900.0;
    xi[1]=-sqrt(245-14*sqrt(70))/21.0;
    weights[1]=(322.0+13*sqrt(70))/900.0;
    xi[2]=0;
    weights[2]=128.0/225.0;
    xi[3]=-xi[1];
    weights[3]=weights[1];
    xi[4]=-xi[0];
    weights[4]=weights[0];
  }
}

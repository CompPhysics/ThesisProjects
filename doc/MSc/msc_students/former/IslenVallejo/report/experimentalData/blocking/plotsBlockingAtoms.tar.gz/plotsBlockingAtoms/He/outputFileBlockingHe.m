nsd           = 3;
nel           = 2;
potpar        = 2.00;
nmc           = 10000000;
nth           = 1000000;
nvp           = 2;
alpha = 1.8377;
beta = 0.34791;
percentAccept = 99.69;
energy        =      -2.8899506;
variance      =      0.14242367;
error         =   5.9670695E-05;


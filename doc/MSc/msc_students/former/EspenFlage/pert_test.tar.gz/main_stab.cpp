#include "Diag.h"

// main
int main (int argc, const char* argv[]) {

  // initialize
  Diag myDiag;
  
  // Define input parameters
  int N;
  int L_or_M;
  int l_or_m;
  int n_mark_max;
  double factor;
  int dim;
  // ask user
  cout << "What dimension? [3=3D, 2=2D]" << endl;
  cin >> dim;
  if (dim==2) {
    cout << "Input 'N[int] M[int] m[int] n_mark_max[int] factor[double]'" << endl;
  }
  else {
    cout << "Input 'N[int] L[int] l[int] n_mark_max[int] factor[double]'" << endl;
  }
    cin >> N >> L_or_M >> l_or_m >> n_mark_max >> factor;
    cout << endl;
    cout << "Starting diagonalization using numerical integration for" << endl;
  cout << "----------------------------------------------------" << endl;
  cout << "|N=" << N << "  |L_or_M=" << L_or_M << "  |l_or_m=" << l_or_m << "  |n_mark_max=" << n_mark_max << "   |l_0/a_0=" << factor << "      | " << endl;
  cout << "----------------------------------------------------" << endl;

    
    
  // Check if n_mark_max=0. This give error in tred2.
  if (n_mark_max==0) {
    cout << "Syntax error!" << endl;
    cout << "n_mark_max need to be greater than zero" << endl;
    exit(1);
  }

  ofstream outFile("dump");

  double p=0.0;
  double p_step=0.01;
  int factorial_max;
  vector<double> d(n_mark_max+1);
  vector<double> e(n_mark_max+1);
  vector<double> weights(60);
  vector<double> points(60);

  if (dim==2) {
    factorial_max=(n_mark_max+abs(l_or_m))+1;
    myDiag.gaulag(points,weights,(double)(abs(l_or_m)-0.5));
    //myDiag.gauleg(0.0,50.0,points,weights);
  }
  else {
    factorial_max=2*(n_mark_max+abs(l_or_m))+2;
    myDiag.gaulag(points,weights,(double)l_or_m);  
    //myDiag.gauleg(0.0,50.0,points,weights); 
  }
  
  vector<double> factorialln(factorial_max+1); 
  myDiag.factorialln(factorialln);

  while (p<=60.0) {
    // denne er MEGET fishy!
    vector<vector<double> > eigen(n_mark_max+1,vector<double>(n_mark_max+1));
    d.empty();
    e.empty();
    
    // fill the matrix
    myDiag.matrix_num_int(N,abs(L_or_M),abs(l_or_m),n_mark_max,dim,p,factorialln,eigen,points,weights);
    
    // diagonalize
    myDiag.tred2(eigen,d,e);
    myDiag.tqli(d,e,eigen);
    myDiag.sort_tridiag(d);

    outFile << p;
    outFile.put(' ');
    for (int i=1; i<=n_mark_max; i++) {
      outFile << (fabs(d[i]-myDiag.perturbation(i-1,l_or_m,dim,n_mark_max,p,factorialln,points,weights)))/d[i];
      outFile.put(' ');
    }
    outFile << endl;
    printf("p=%f\n",p);
    if (p>=0.1) {
      p_step=0.1;
    }
    if (p>=1.0) {
      p_step=0.2;
    }
    if (p>=2.0) {
      p_step=0.5;
    }
    if (p>=10.0) {
      p_step=5.0;
    }
    p+=p_step;
  }
  outFile.close();
  return 0;
}

#include "Diag.h"
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
static double sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)
#define EPS 3.0e-14
#define MAXIT 10

/* All methods in this file originates from Numerical Recipes. Some of them have undergone slight modifications to datatypes, but the routines remain the same
 */

// gammln:Calculates the logarithme of the gamma function
double Diag::gammln(double n) {

  double x,y,tmp,ser;
  static double cof[6]={76.18009172947146,-86.50532032941677,
			24.01409824083091,-1.231739572450155,
			0.1208650973866179e-2,-0.5395239384953e-5};
  int j;
  y=x=n;
  tmp=x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser=1.000000000190015;
  for (j=0;j<=5;j++) ser += cof[j]/++y;
  return -tmp+log(2.5066282746310005*ser/x);
}

// tqli:Finds eigenvalues and eigenvectors of a tridiagonal matrix.
void Diag::tqli(vector<double> &d, vector<double> &e, vector<vector<double> > &z) {

  //  double pythag(double a, double b);
  int n=d.size()-1;
  int m,l,iter,i,k;
  double s,r,p,g,f,dd,c,b;
  
  for (i=2;i<=n;i++) e[i-1]=e[i];
  e[n]=0.0;
  for (l=1;l<=n;l++) {
    iter=0;
    do {
      for (m=l;m<=n-1;m++) {
	dd=fabs(d[m])+fabs(d[m+1]);
	if ((double)(fabs(e[m])+dd) == dd) break;
      }
      if (m != l) {
	if (iter++ == 30) printf("Too many iterations in tqli");
	g=(d[l+1]-d[l])/(2.0*e[l]);
	r=pythag(g,1.0);
	g=d[m]-d[l]+e[l]/(g+SIGN(r,g));
	s=c=1.0;
	p=0.0;
	for (i=m-1;i>=l;i--) {
	  f=s*e[i];
	  b=c*e[i];
	  e[i+1]=(r=pythag(f,g));
	  if (r == 0.0) {
	    d[i+1] -= p;
	    e[m]=0.0;
	    break;
	  }
	  s=f/r;
	  c=g/r;
	  g=d[i+1]-p;
	  r=(d[i]-g)*s+2.0*c*b;
	  d[i+1]=g+(p=s*r);
	  g=c*r-b;
	  // this can be omitted if eigenvectors not wanted
	  /*
	  for (k=1;k<=n;k++) {
	    f=z[k][i+1];
	    z[k][i+1]=s*z[k][i]+c*f;
	    z[k][i]=c*z[k][i]-s*f;
	  }
	  */
	}
	if (r == 0.0 && i >= l) continue;
	d[l] -= p;
	e[l]=g;
	e[m]=0.0;
      }
    } while (m != l);
  }
}


// pythag: tqli uses this
double Diag::pythag(double a, double b) {

  double absa,absb;
  absa=fabs(a);
  absb=fabs(b);
  if (absa > absb) return absa*sqrt(1.0+SQR(absb/absa));
  else return (absb == 0.0 ? 0.0 : absb*sqrt(1.0+SQR(absa/absb)));
}


// tred2: Matrix reduction to tridigonal form using Housholder reduction
void Diag::tred2(vector<vector<double> > &a, vector<double> &d, vector<double> &e) {

  int n=d.size()-1;
  int l,k,j,i;
  float scale,hh,h,g,f;
  
  for (i=n;i>=2;i--) {
    l=i-1;
    h=scale=0.0;
    if (l > 1) {
      for (k=1;k<=l;k++)
	scale += fabs(a[i][k]);
      if (scale == 0.0)
	e[i]=a[i][l];
      else {
	for (k=1;k<=l;k++) {
	  a[i][k] /= scale;
	  h += a[i][k]*a[i][k];
	}
	f=a[i][l];
	g=(f >= 0.0 ? -sqrt(h) : sqrt(h));
	e[i]=scale*g;
	h -= f*g;
	a[i][l]=f-g;
	f=0.0;
	for (j=1;j<=l;j++) {
	  a[j][i]=a[i][j]/h;
	  g=0.0;
	  for (k=1;k<=j;k++)
	    g += a[j][k]*a[i][k];
	  for (k=j+1;k<=l;k++)
	    g += a[k][j]*a[i][k];
	  e[j]=g/h;
	  f += e[j]*a[i][j];
	}
	hh=f/(h+h);
	for (j=1;j<=l;j++) {
	  f=a[i][j];
	  e[j]=g=e[j]-hh*f;
	  for (k=1;k<=j;k++)
	    a[j][k] -= (f*e[k]+g*a[i][k]);
	}
      }
    } else
      e[i]=a[i][l];
    d[i]=h;
  }
  d[1]=0.0;
  e[1]=0.0;

  /* Contents of this loop can be omitted if eigenvectors not
     wanted except for statement d[i]=a[i][i]; */
  
  for (i=1;i<=n;i++) {
    /*
    l=i-1;
    if (d[i]) {
      for (j=1;j<=l;j++) {
	g=0.0;
	for (k=1;k<=l;k++)
	  g += a[i][k]*a[k][j];
	for (k=1;k<=l;k++)
	  a[k][j] -= g*a[k][i];
      }
    }
    */
    d[i]=a[i][i];
    /*
    a[i][i]=1.0;
    for (j=1;j<=l;j++) a[j][i]=a[i][j]=0.0;
    */
    }
}

// gaulag:Calculates Gauss-Laguerre integrations weights and points
void Diag::gaulag(vector<double> &x, vector<double> &w, double alf) {
  int n=x.size()-1;
  int i,its,j;
  float ai;
  double p1,p2,p3,pp,z,z1;                                                   
  for (i=1;i<=n;i++) {                       
    if (i == 1) {                         
      z=(1.0+alf)*(3.0+0.92*alf)/(1.0+2.4*n+1.8*alf);
    } else if (i == 2) {                   
      z += (15.0+6.25*alf)/(1.0+0.9*alf+2.5*n);
    } else {                               
      ai=i-2;
      z += ((1.0+2.55*ai)/(1.9*ai)+1.26*ai*alf/
	    (1.0+3.5*ai))*(z-x[i-2])/(1.0+0.3*alf);
    }
    for (its=1;its<=MAXIT;its++) {         
      p1=1.0;
      p2=0.0;
      for (j=1;j<=n;j++) {               
	p3=p2;                               
	p2=p1;
	p1=((2*j-1+alf-z)*p2-(j-1+alf)*p3)/j;
      }
      pp=(n*p1-(n+alf)*p2)/z;
      z1=z;
      z=z1-p1/pp;                          
      if (fabs(z-z1) <= EPS) {
	break;
      }
    }
    
    if (its > MAXIT) {
      printf("too many iterations in gaulag\n");
      printf("its=%d\n",its);
      printf("n=%d\n",i);
    }
    x[i]=z;                             
    w[i] = -exp(gammln(alf+n)-gammln((double)n))/(pp*n*p2);
  }
}


void Diag::gauleg(double x1, double x2, vector<double> &x, vector<double> &w) {
  
  int n=x.size()-1;
  int m,j,i;                                      
  double z1,z,xm,xl,pp,p3,p2,p1;
  
  m=(n+1)/2;                                                
  xm=0.5*(x2+x1);
  xl=0.5*(x2-x1);                                        
  for (i=1;i<=m;i++) {
    z=cos(3.141592654*(i-0.25)/(n+0.5));
    do {
      p1=1.0;
      p2=0.0;                                   
      for (j=1;j<=n;j++) {                                      
	p3=p2;
	p2=p1;
	p1=((2.0*j-1.0)*z*p2-(j-1.0)*p3)/j;
      }
      pp=n*(z*p1-p2)/(z*z-1.0);
      z1=z;                               
      z=z1-p1/pp;
    } while (fabs(z-z1) > EPS);                                    
    x[i]=xm-xl*z;                         
    x[n+1-i]=xm+xl*z;                                      
    w[i]=2.0*xl/((1.0-z*z)*pp*pp);                                      
    w[n+1-i]=w[i];
  }
}

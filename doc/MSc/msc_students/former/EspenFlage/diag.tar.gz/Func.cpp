#include "Diag.h"

// generates the Laguerre polynomials used in mass-center therm

double Diag::genLaguerre(int n,double m, double x) {

  vector<double> laguerpol(n+3);

  // calculate laguerre polynomial terms using recursive iterations

  if (m<0) {
    printf("Error in M. Use M>=0, terminating\n");
    exit(1);
  }

  laguerpol[0]=1.0;
  laguerpol[1]=m+1.0-x;
  laguerpol[2]=0.5*(x*x-2.0*(m+2)*x+(m+1)*(m+2));

  for (int i=3;i<=n;i++) {
    laguerpol[i]=(((double)(2*i+m-1)-x)*laguerpol[i-1]-(double)(i+m-1)*laguerpol[i-2])/(double)(i);
  }
  
  return(laguerpol[n]);
}


double Diag::func(int n,int n_mark, int m, double x) {
  return(pow(x,2.0*((double)abs(m)))*exp(-x*x)*genLaguerre(n,m,x*x)*genLaguerre(n_mark,m,x*x));
}

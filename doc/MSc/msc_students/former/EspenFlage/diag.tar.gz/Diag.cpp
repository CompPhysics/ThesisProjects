#include "Diag.h"
#define PI 3.141592653589793238462643383279502884197

string filename_base="eig";
string filename_type_one="N";
string filename_type_two="S";
string matrix="M";
string plot="P";

/* All methods in this file takes care of the matrix structures and calculates the diagonal and of diagonal matrix elements
 */

// non_diag_matrix:Calculates and fill both diagonal and off-diagonal matrix elements
double Diag::matrix_series(int m,int n_mark_max, int dim, double factor,vector<double> &factorialsln,vector<vector<double> > &eigen) {
  
  // define output filenames
  string filename_ext;
  string filename_matrix;
  string filename_plot;
  stringstream ssin(filename_ext, ios_base::out);
  ssin << dim << "D" << m << "_" << n_mark_max << ".out";
  filename_ext = ssin.str();
  filename_matrix=filename_base+filename_type_two+matrix+filename_ext;
  filename_plot=filename_base+filename_type_two+plot+filename_ext;
  ofstream outFile(filename_matrix.c_str());
  ofstream outFile2(filename_plot.c_str());
  
  for (int i=1; i<=n_mark_max;i++) {
    for (int j=1; j<=n_mark_max;j++) {

      // fill diagonal elements
      
      if (i==j) {
	if (dim==2) {
	  eigen[i][j]=2*(i-1)+m+1.0+factor*perturbation_elements((i-1),(i-1),m,dim,factorialsln);
	}
	else {
	  eigen[i][j]=2*(i-1)+m+1.5+factor*perturbation_elements((i-1),(i-1),m,dim,factorialsln);

	}
      }

      // fill non-diag elements
      else {
	eigen[i][j]=factor*perturbation_elements((i-1),(j-1),m,dim,factorialsln);
      }
       
      outFile << eigen[i][j];
      outFile2 << i-1;
      outFile2.put(' ');
      outFile2 << j-1;
      outFile2.put(' ');
      outFile2 << eigen[i][j] << endl;
      outFile.put(' ');	
      
    }
    outFile << endl;
    
  }
  outFile.close();
  outFile2.close();
 
}

double Diag::matrix_num_int(int m,int n_mark_max, int dim,double factor,vector<double> &factorialsln,vector<vector<double> > &eigen,vector<double> &points, vector<double> &weights) {
  
  // define output filenames
 
  string filename_ext;
  string filename_matrix;
  string filename_plot;
  stringstream ssin(filename_ext, ios_base::out);
  ssin << dim << "D" << m << "_" << n_mark_max << ".out";
  filename_ext = ssin.str();
  filename_matrix=filename_base+filename_type_one+matrix+filename_ext;
  filename_plot=filename_base+filename_type_one+plot+filename_ext;
  ofstream outFile(filename_matrix.c_str());
  ofstream outFile2(filename_plot.c_str());

  //gauss quandrat integration
  for (int i=1; i<=n_mark_max;i++) {
    for (int j=1; j<=n_mark_max;j++) {
      if (i==j) {
	if (dim==2) {
	  //eigen[i][j]=factor*0.5*exp(factorialsln[i-1]-factorialsln[i-1+m])*numeric_integration_gauss(i-1,i-1,m,dim,points,weights);
	  eigen[i][j]=2*(i-1)+m+1.0+factor*exp(factorialsln[i-1]-factorialsln[i-1+m])*numeric_integration_gauss(i-1,i-1,m,dim,points,weights);
	}
	else {
	  //eigen[i][j]=factor*0.5*(pow(2.0,2*(i-1+m)+1)/sqrt(PI))*exp(factorialsln[i-1]+factorialsln[i-1+m]-factorialsln[2*(i-1+m)+1])*numeric_integration_gauss(i-1,i-1,m,dim,points,weights);
	  eigen[i][j]=2*(i-1)+m+1.5+factor*(pow(2.0,2*(i-1+m)+1)/sqrt(PI))*exp(factorialsln[i-1]+factorialsln[i-1+m]-factorialsln[2*(i-1+m)+1])*numeric_integration_gauss(i-1,i-1,m,dim,points,weights);
	}
      }
      else {
	if (dim==2) {
	  //eigen[i][j]=factor*0.5*exp(0.5*(factorialsln[i-1]+factorialsln[j-1]-factorialsln[i-1+m]-factorialsln[j-1+m]))*numeric_integration_gauss(i-1,j-1,m,dim,points,weights);
	  eigen[i][j]=factor*exp(0.5*(factorialsln[i-1]+factorialsln[j-1]-factorialsln[i-1+m]-factorialsln[j-1+m]))*numeric_integration_gauss(i-1,j-1,m,dim,points,weights);
	}
	else {
	  eigen[i][j]=factor*exp(0.5*(factorialsln[i-1]+factorialsln[j-1]+factorialsln[i-1+m]+factorialsln[j-1+m]+log(pow(2.0,2*(i-1+m)+1))+log(pow(2.0,2*(j-1+m)+1))-log(PI)-factorialsln[2*(i-1+m)+1]-factorialsln[2*(j-1+m)+1]))*numeric_integration_gauss(i-1,j-1,m,dim,points,weights);
	  //eigen[i][j]=factor*0.5*exp(0.5*(factorialsln[i-1]+factorialsln[j-1]+factorialsln[i-1+m]+factorialsln[j-1+m]+log(pow(2.0,2*(i-1+m)+1))+log(pow(2.0,2*(j-1+m)+1))-log(PI)-factorialsln[2*(i-1+m)+1]-factorialsln[2*(j-1+m)+1]))*numeric_integration_gauss(i-1,j-1,m,dim,points,weights);
	}
      }
      
      outFile << eigen[i][j];
      outFile2 << i-1;
      outFile2.put(' ');
      outFile2 << j-1;
      outFile2.put(' ');
      outFile2 << eigen[i][j] << endl;
      outFile.put(' ');				     
      
    }
    outFile << endl;
  }
  
  outFile.close();
  outFile2.close();
  
}



// non_diag_matrix_elements:Calculates the perturbed elements from the Coulomb potential
double Diag::perturbation_elements(int n,int n_mark,int m,int dim,vector<double> &factorialsln) {

  double sum=0.0;
  double sign;
  double fact_one;
  double frac_fact_one;
  double frac_fact_two;
  double talmi_int;
  
  // use k' and k direct sums using direct evaluation of the factorialsln
  
  if (dim==2) {
    fact_one=0.5*(factorialsln[n]+factorialsln[n_mark]+factorialsln[n+m]+factorialsln[n_mark+m]);
  }
  else {
    fact_one=0.5*(factorialsln[n]+factorialsln[n_mark]+log(sqrt(PI)/pow(2.0,2*(n+m)+1))+factorialsln[2*(n+m)+1]-factorialsln[n+m]+log(sqrt(PI)/pow(2.0,2*(n_mark+m)+1))+factorialsln[2*(n_mark+m)+1]-factorialsln[n_mark+m]);
  }
  for (int k=0;k<=n;k++) {
    for (int k_mark=0;k_mark<=n_mark;k_mark++) {
      if ((k_mark+k) % 2 == 0) {
	sign=1.0;
      }
      else {
	sign=-1.0;
      }
      if (dim==2) {
	frac_fact_one=factorialsln[n_mark-k_mark]+factorialsln[m+k_mark]+factorialsln[k_mark];
	frac_fact_two=factorialsln[n-k]+factorialsln[m+k]+factorialsln[k];	
	talmi_int=exp(gammln(k_mark+k+m+0.5))/2.0;
      }
      else {
	frac_fact_one=factorialsln[n_mark-k_mark]+log(sqrt(PI)/pow(2.0,(2.0*((double)(m+k_mark))+1.0)))+factorialsln[2*(m+k_mark)+1]-factorialsln[m+k_mark]+factorialsln[k_mark];
	frac_fact_two=factorialsln[n-k]+log(sqrt(PI)/pow(2.0,(2.0*((double)(k+m))+1.0)))+factorialsln[2*(m+k)+1]-factorialsln[k+m]+factorialsln[k];
	talmi_int=exp(gammln((2.0*(k_mark+k+m+0.5)+1.0)/2.0))/2.0;	
      }
      sum+=sign*2.0*exp(fact_one-frac_fact_one-frac_fact_two)*talmi_int;
      
    }
  }
  return(sum);
  
  // use gammln method
  /*
  if (dim==2) {
      fact_one=0.5*(gammln((double)(n+1))+gammln((double)(n_mark+1))+gammln((double)(n+m+1))+gammln((double)(n_mark+m+1)));
  }
  else {
    fact_one=0.5*(gammln((double)(n+1))+gammln((double)(n_mark+1))+log((sqrt(PI)/pow(2.0,2*(n+m)+1))*factorialsln[2*(n+m)+1]/factorialsln[n+m])+log((sqrt(PI)/pow(2.0,2*(n_mark+m)+1)))+gammln((double)(2*(n_mark+m)+1+1))-gammln((double)(n_mark+m+1)));
  }
  for (int k=0;k<=n;k++) {
    for (int k_mark=0;k_mark<=n_mark;k_mark++) {
      if ((k_mark+k) % 2 == 0) {
	sign=1.0;
      }
      else {
	sign=-1.0;
      }
      if (dim==2) {
	frac_fact_one=gammln((double)(n_mark-k_mark+1))+gammln((double)(m+k_mark+1))+gammln((double)(k_mark+1));
	frac_fact_two=gammln((double)(n-k+1))+gammln((double)(m+k+1))+gammln((double)(k+1));
	talmi_int=exp(gammln((2.0*(k_mark+k+m)+1.0)/2.0))/2.0;
      }
      else {
	frac_fact_one=gammln((double)(n_mark-k_mark+1))+log((sqrt(PI)/pow(2.0,(2.0*((double)(m+k_mark))+1.0))))+gammln((double)(2*(m+k_mark)+1+1))-gammln((double)(m+k_mark+1))+gammln((double)(k_mark+1));
	frac_fact_two=gammln((double)(n-k+1))+log((sqrt(PI)/pow(2.0,(2.0*((double)(k+m))+1.0))))+gammln((double)(2*(m+k)+1+1))-gammln((double)(k+m+1))+gammln((double)(k+1));
	talmi_int=exp(gammln((2.0*(k_mark+k+m+0.5)+1.0)/2.0))/2.0;	
      }
      sum+=sign*2.0*exp(fact_one-frac_fact_one-frac_fact_two)*talmi_int;
      
    }
  }
  return(sum);
  */
}


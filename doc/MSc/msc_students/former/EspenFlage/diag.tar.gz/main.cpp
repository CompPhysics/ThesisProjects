#include "Diag.h"

// main
int main (int argc, const char* argv[]) {

  // initialize
  Diag myDiag;
  
  // Define input parameters
  int N;
  int L_or_M;
  int l_or_m;
  int n_mark_max;
  double factor;
  double dim_value;
  int dim;
  int num_int;
  int units;

  // ask user
  cout << "What dimension? [3=3D, 2=2D]" << endl;
  cin >> dim;
  cout << "Do you want to use numerical integration? [yes=1,no=0]" << endl;
  cin >> num_int;
  cout << "Do you want energy in eV units? [yes=1,no=0]" << endl;
  cin >> units;
  if (units==1) {
    if (dim==2) {
      cout << "Input 'N[int] M[int] m[int] n_mark_max[int] l_0[double]'" << endl;
    }
    else {
      cout << "Input 'N[int] L[int] l[int] n_mark_max[int] l_0[double]'" << endl;
    }
  }
  else {
    if (dim==2) {
      cout << "Input 'N[int] M[int] m[int] n_mark_max[int] factor[double]'" << endl;
    }
    else {
      cout << "Input 'N[int] L[int] l[int] n_mark_max[int] factor[double]'" << endl;
    }
  }
    cin >> N >> L_or_M >> l_or_m >> n_mark_max >> factor;
  cout << endl;
  if (num_int==1) {
    cout << "Starting diagonalization using numerical integration for" << endl;
  }
  else {
    cout << "Starting diagonalization using series expansion for" << endl;
  }
  cout << "----------------------------------------------------" << endl;
  if (units==1) {
    cout << "|N=" << N << "  |L_or_M=" << L_or_M << "  |l_or_m=" << l_or_m << "  |n_mark_max=" << n_mark_max << "   |l_0=" << factor << "      | " << endl;
  }
  else {
    cout << "|N=" << N << "  |L_or_M=" << L_or_M << "  |l_or_m=" << l_or_m << "  |n_mark_max=" << n_mark_max << "   |l_0/a_0=" << factor << "      | " << endl;
  }
  cout << "----------------------------------------------------" << endl;

    
    
  // Check if n_mark_max=0. This give error in tred2.
  if (n_mark_max==0) {
    cout << "Syntax error!" << endl;
    cout << "n_mark_max need to be greater than zero" << endl;
    exit(1);
  }
  
  int factorial_max=2*(n_mark_max+abs(l_or_m))+2;

  if (dim==2) {
    dim_value=1.0;
  }
  else {
    dim_value=1.5;
  }

  // define vectors
  vector<vector<double> > eigen((n_mark_max+1),vector<double>(n_mark_max+1));
  vector<double> d(n_mark_max+1);
  vector<double> e(n_mark_max+1);
  vector<double> factorialsln(factorial_max+1); 
  vector<double> weights(n_mark_max+1);
  vector<double> points(n_mark_max+1);
  vector<double> terms(n_mark_max+4);

  //fill the factorials vector
  myDiag.factorialln(factorialsln);
  
  // fill the matrix
  if (num_int == 0) {
    myDiag.matrix_series(abs(l_or_m),n_mark_max,dim,factor,factorialsln,eigen);
  }
  else {
    if (dim==2) {
      myDiag.gaulag(points,weights,(abs(l_or_m)-0.5));
    }
    else {
      myDiag.gaulag(points,weights,(double)l_or_m);
    }
    if (units==1) {
      myDiag.matrix_num_int(abs(l_or_m),n_mark_max,dim,18.89726128*factor,factorialsln,eigen,points,weights);
    }
    else {
      myDiag.matrix_num_int(abs(l_or_m),n_mark_max,dim,factor,factorialsln,eigen,points,weights);
    }
  }
  // diagonalize
  myDiag.tred2(eigen,d,e);
  myDiag.tqli(d,e,eigen);
  myDiag.sort_tridiag(d);

  cout << endl;
  cout << endl;
  cout << "Printing out eigenvalues for <n'm|k/r|nm>" << endl;
  cout << "----------------------------------------------------" << endl;
  cout << "n" << "      "  << "E, diag" << "       " << "      " << "2. order" << endl; 
  // print the eigenvalues
  double crit;
  for (int i=1;i<=n_mark_max;i++) {
    cout << "$" << i-1 << "$" << "&" <<"   " ;
    if (units==1) {
      printf("$%f$",d[i]*0.0761996368846/pow(factor,2.0));
    }
    else {
      printf("$%f$",d[i]+(2*N+L_or_M+dim_value));
    }
    if (num_int==1) {
      // calculate eigenvalues using perturbation theory
      crit=myDiag.perturbation(i-1,l_or_m,dim,n_mark_max,factor,factorialsln,points,weights,terms);
      cout << "&" << "   " ;
      //cout << "   ";
      //printf("$%f$",terms[0]+terms[1]+(2*N+L_or_M+dim_value));
      cout << "   ";
      if (crit <= 0.5) {
	printf("$%f$",terms[0]+terms[1]+terms[2]+(2*N+L_or_M+dim_value)); 
      }
      else {					
	printf("$   n/a   $"); 
      }
    }
    printf("\\");
    printf("\\");
    cout << endl;
  }
  return 0;
}

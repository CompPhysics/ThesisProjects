#include "Diag.h"
#define PI 3.141592654

/* All methods who calculates and sorts are placed here
 */

// sort_tridiag:Sorting eigenvalues, smallest first
void Diag::sort_tridiag(vector<double> &d) {
  int n=d.size()-1;
  for (int i = 1; i < n; i++) {
    int k = i;
    double temp = fabs(d[i]);
    for (int j = i+1; j <=n; j++) {
      if (fabs(d[j]) < temp) {
	k = j;
	temp = d[j];
      }
    }
    if (k != i) {
      d[k] = d[i];
      d[i] = temp;
    }
  }
}


// factorial:Calculate factorials and store them in a vector
void Diag::factorialln(vector<double> &factorialsln) {
  int factorial_max=factorialsln.size();
  for (int n=0;n<factorial_max;n++) {
    if (n<=160) {
      if(n <= 1) {
	factorialsln[n]=0.0; 
      }
      else {
	factorialsln[n] = log(n) + factorialsln[n - 1];
      }
    }
    else {
      factorialsln[n]=gammln(n+1);
    }
  } 
}

// factorial_true:Prints the true factorial using strings. For control purpose.
double Diag::factorial_true(int n) {
 
  unsigned int nd, nz;   // number of digits
  unsigned char *ca;     // char array to hold result
  unsigned int j, q, temp;
  int i;
  double p;
 
  //calculate nd = the number of digits required
  p = 0.0;
  // p is really log10(n!)
  for(j = 2; j <= n; j++)
    {
      p += log10((double)j);   // cast to double
    }
  
  nd = (int)p + 1;
  // allocate memory for the char array
  ca = new unsigned char[nd];
  if (!ca)
    {
      cout << "Could not allocate memory!!!";
      exit(0);
    }
  //initialize char array
  for (i = 1; i < nd; i++)
    {
      ca[i] = 0;
    }
  ca[0] = 1;
  
  // put the result into a numeric string using the array of characters
  p = 0.0;
  for (j = 2; j <= n; j++)
    {
      p += log10((double)j);   // cast to double!!!
      nz = (int)p + 1;         // number of digits to put into ca[]
      q = 0;                   // initialize remainder to be 0
      for (i = 0; i <= nz; i++)
	{
	  temp = (ca[i] * j) + q;
	  q = (temp / 10);
	  ca[i] = (char)(temp % 10);
	}
    }
  cout << "mm=";
  for( i = nd - 1; i >= 0; i--)
    {
      cout << (int)ca[i];
    }
  cout << endl;
  
}

// numeric_integration_gauss:Numerical integration using Gauss-Laguerre
double Diag::numeric_integration_gauss(int n, int n_mark, int m, int dim,vector<double> &points,vector<double> &weights) {
  double temp=0.0;
  int maxpol=points.size();
  if (dim==2) {
    for (int i=1;i<=maxpol;i++) {
      temp+=weights[i]*genLaguerre(n,(double)m,points[i])*genLaguerre(n_mark,(double)m,points[i]);
    }
  }
  else {
    for (int i=1;i<=maxpol;i++) {
      temp+=weights[i]*genLaguerre(n,m+0.5,points[i])*genLaguerre(n_mark,m+0.5,points[i]);
    }
  }
  
  return(temp);
}

double Diag::perturbation(int n, int m, int dim, int max, double factor,vector<double> &factorialsln,vector<double> &points,vector<double> &weights,vector<double> &terms) {

  double second_term=0.0;
  double pert_ratio;

  for (int i=0;i<=max;i++) {
    if (i != n) {
      if (dim==2) {
	pert_ratio=fabs(factor*exp(0.5*(factorialsln[i]+factorialsln[n]-factorialsln[i+m]-factorialsln[n+m]))*numeric_integration_gauss(i,n,m,dim,points,weights))/(2*n+m+1.0-(2*i+m+1.0));
	if (pert_ratio > 0.5) {
	  break;
	}
	second_term+=pert_ratio*fabs(factor*exp(0.5*(factorialsln[i]+factorialsln[n]-factorialsln[i+m]-factorialsln[n+m]))*numeric_integration_gauss(i,n,m,dim,points,weights));
      }
      else {
	pert_ratio=fabs(factor*exp(0.5*(factorialsln[i]+factorialsln[n]+factorialsln[i+m]+factorialsln[n+m]+log(pow(2.0,2*(i+m)+1))+log(pow(2.0,2*(n+m)+1))-log(PI)-factorialsln[2*(i+m)+1]-factorialsln[2*(n+m)+1]))*numeric_integration_gauss(i,n,m,dim,points,weights))/(2*n+m+1.5-(2*i+m+1.5));
	if (pert_ratio > 0.5) {
	  break;
	}
	second_term+=pert_ratio*fabs(factor*exp(0.5*(factorialsln[i]+factorialsln[n]+factorialsln[i+m]+factorialsln[n+m]+log(pow(2.0,2*(i+m)+1))+log(pow(2.0,2*(n+m)+1))-log(PI)-factorialsln[2*(i+m)+1]-factorialsln[2*(n+m)+1]))*numeric_integration_gauss(i,n,m,dim,points,weights));
      }
      
    }
  }
  terms[2]=second_term;
  
  if (dim==2) {
    terms[0]=2*n+m+1.0;
    terms[1]=factor*exp(factorialsln[n]-factorialsln[n+m])*numeric_integration_gauss(n,n,m,dim,points,weights); 
  }
  
  else {
    terms[0]=2*n+m+1.5;
    terms[1]=factor*(pow(2.0,2*(n+m)+1)/sqrt(PI))*exp(factorialsln[n]+factorialsln[n+m]-factorialsln[2*(n+m)+1])*numeric_integration_gauss(n,n,m,dim,points,weights);
  }
  return (pert_ratio);
}


#ifndef walker_hpp_IS_INCLUDED
#define walker_hpp_IS_INCLUDED

// class containing information with regards to a walker

#include "QickArray/QickArray.hpp"
#include "particle.hpp"
#include "functions.hpp"

class Walker{

private:

  Particle  *particles;
  QickArray params;
  bool dead, old_eq_new;
  int dim, no_of_particles;
  int particles_moved;

  Func *local_e_ptr, *wf_ptr, *q_force_ptr, *hamilton_ptr,
    *potential_ptr;
  
  QickArray& posVec();

public:

  Walker(int no_of_particles_);

  ~Walker(){
    delete[] particles;
    delete   local_e_ptr;
    delete   wf_ptr;
    delete   q_force_ptr;
    delete   hamilton_ptr;
    delete   potential_ptr;
  }

  double getParticlePosition(int i, int j); // returns j'th coord position 
                                    // of i'th particle
  double getNewParticlePosition(int i, int j); // returns j'th coord position 
                                    // of i'th particle's new pos
  void setParticlePosition(int i, int j, double x); // set's value of 
                                                    //j'th coord,
                                                    // i'th particle
  void updateParticlePosition(int i); // pos=new_pos
  void resetParticlePosition(int i); // new_pos=pos

  inline void setParams(QickArray& params_){ params=params_; }

  double getLocalEnergy();

  double getWaveFunction();

  QickArray& getQuantumForce();
  
  double getLocalEnergy(int i);

  double getWaveFunction(int i);

  QickArray& getQuantumForce(int i);
  
  inline void killWalker(){ dead=true; }

  inline bool isDead(){ return dead; }

  inline int getNoOfParticles(){ return no_of_particles; }

  inline int getDimension(){ return dim; }

  Walker& operator=(const Walker& clone_me);

};

inline double Walker:: getParticlePosition(int i, int j){
  return particles[i].getPosition(j);
}

inline double Walker:: getNewParticlePosition(int i, int j){
  return particles[i].getNewPosition(j);
}

inline void Walker:: setParticlePosition(int i, int j, double x){
  particles[i].setPosition(j,x);
  old_eq_new = false;
}

inline void Walker:: updateParticlePosition(int i){
  particles[i].updatePosition();
  old_eq_new = true;
}

inline void Walker:: resetParticlePosition(int i){
  particles[i].resetPosition();
  old_eq_new = true;
}

inline double Walker:: getLocalEnergy(){
  return (*local_e_ptr)((*wf_ptr), (*hamilton_ptr), 
			(*potential_ptr), posVec(), params);
} // end getLocalEnergy


inline double Walker:: getWaveFunction(){
  return (*wf_ptr)(posVec(), params);
} // end getWaveFunction


inline QickArray& Walker:: getQuantumForce(){
  static QickArray dummy(dim);
  return (*q_force_ptr)((*wf_ptr), posVec(), dummy, params);
} // end getQuantumForce

// not implemented yet
inline double Walker:: getLocalEnergy(int i){
  return 0;
} // end getLocalEnergy

// not implemented yet
inline double Walker:: getWaveFunction(int i){
  return 0;
} // end getWaveFunction

// not implemented yet
inline QickArray& Walker:: getQuantumForce(int i){
  static QickArray dummy;
  return dummy;
} // end getQuantumForce

// function returning new position of particles as a matrix,
// allways returning new position as this equals old position 
// when necessary.
inline QickArray& Walker:: posVec(){
  static QickArray pos(no_of_particles, dim);
  for(int i=0; i!=no_of_particles; i++)
    for(int j=0; j!=dim; j++)
      pos(i,j) = getNewParticlePosition(i,j);
  return pos;
}

#endif

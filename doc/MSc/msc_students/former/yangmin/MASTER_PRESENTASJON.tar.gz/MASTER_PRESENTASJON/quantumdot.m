clc
close all
clear all

format long
omega = 1;
N = 30;
lx = 2.5;
V0 = 8;
% a = 1.4263;
a = 1.28;

%discretize
nx = 1000;
steps = nx;
x_min = -6;
x_max =  6;
h = (x_max - x_min)/nx;
x = x_min:h:x_max;
y = x_min:h:x_max;

t = zeros(steps+1);
e = 0.5*(-1.0*omega)/h^2;
f = 1.0/h^2;
for k=1:steps,
    %filling the diagonal
    x = x_min + (k-1)*h;
%     v = 0.5*omega*x.^2 + V0*exp(-x.*x*0.5);
 v = 0.5*omega*x.^2 + V0*exp(-(x-a).*(x-a)*0.5) + V0*exp(-(x+a).*(x+a)*0.5);
    t(k,k) = f + v;
    
    %filling the first off-diagonals for u_{i+1,j} u_{j,i+1}
    t(k,k+1) = e;
    t(k+1,k) = e;
end
%have to divide the energy on halv
%last diagonal
x = x_min + (k)*h;
% v = 0.5*omega*x.^2 + V0*exp(-x.*x*0.5);
v = 0.5*omega*x.^2 + V0*exp(-(x-a).*(x-a)*0.5) + V0*exp(-(x+a).*(x+a)*0.5);
t(k+1,k+1) = f + v;

x = x_min:h:x_max;
[S,d] = eig(t);

for i=1:N
    norm = trapz(x,S(:,i).*S(:,i));
    S(:,i) = S(:,i)./sqrt(norm);
end

wf = zeros(size(S(:,1)),N);

for i=1:N
    g = Hermite(i-1,x');
    wf(:,i) = g(:,i);
%     norm2 = trapz(x,wf(:,i).*wf(:,i))
%     wf(:,i) = wf(:,i)./sqrt(norm2);
end

[X,Y] = meshgrid(x,x);   

figure(1)
plot(x,S(:,1).*S(:,1));
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
ylabel('|\psi|^2','Fontsize',15)
title('$n_x^\prime = 0 $','Interpreter','Latex','Fontsize',15)

figure(2)
plot(x,S(:,2).*S(:,2));
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
ylabel('|\psi|^2','Fontsize',15)
title('$n_x^\prime = 1 $','Interpreter','Latex','Fontsize',15)

figure(3)
plot(x,S(:,3).*S(:,3));
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
ylabel('|\psi|^2','Fontsize',15)
title('$n_x^\prime = 2 $','Interpreter','Latex','Fontsize',15)

figure(4)
plot(x,S(:,4).*S(:,4));
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
ylabel('|\psi|^2','Fontsize',15)
title('$n_x^\prime = 3 $','Interpreter','Latex','Fontsize',15)

% Z0 = S(:,1)*wf(:,1)'; % 1 2
% Z1 = S(:,2)*wf(:,1)'; % 2 3
% Z2 = S(:,1)*wf(:,2)'; % 4 5 
% Z3 = S(:,2)*wf(:,2)'; % 6 7

Z0 = S(:,1)*wf(:,1)'; % 1 2
Z1 = S(:,2)*wf(:,1)'; % 2 3
Z2 = S(:,3)*wf(:,1)'; % 4 5 
Z3 = S(:,1)*wf(:,2)'; % 6 7

fontsize = 25;
scrsz = get(0,'ScreenSize');
figure('Name','Wf1','Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
imagesc(x,x,(Z0.*Z0)'); 
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
ylabel('$\bar{y} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
title('$p=0 \wedge p=1$','Interpreter','Latex','Fontsize',fontsize)
set(gca,'FontSize',20)

scrsz = get(0,'ScreenSize');
figure('Name','Wf2','Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
imagesc(x,x,(Z1.*Z1)'); 
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
ylabel('$\bar{y} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
title('$p=2 \wedge p=3$','Interpreter','Latex','Fontsize',fontsize)
set(gca,'FontSize',20)

scrsz = get(0,'ScreenSize');
figure('Name','Wf3','Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
imagesc(x,x,(Z2.*Z2)'); 
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
ylabel('$\bar{y} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
title('$p=4 \wedge p=5$','Interpreter','Latex','Fontsize',fontsize)
set(gca,'FontSize',20)

scrsz = get(0,'ScreenSize');
figure('Name','Wf4','Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
imagesc(x,x,(Z3.*Z3)'); 
xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
ylabel('$\bar{y} [l_0]$','Interpreter','Latex','Fontsize',fontsize)
title('$p=6 \wedge p=7$','Interpreter','Latex','Fontsize',fontsize)
set(gca,'FontSize',20)


% 
% figure(1)
% grid on
% box on
% meshc(X,Y,Z.*Z)
% xlabel('$x$','Interpreter','Latex','Fontsize',15)
% ylabel('$y$','Interpreter','Latex','Fontsize',15)
% zlabel('|\psi|^2')
% title('$n_x^\prime = 7 \wedge n_y^\prime = 0$','Interpreter','Latex','Fontsize',15)
% 

% figure(1)
% plot(x,S(:,1));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
% ylabel('\psi(\bar{x})','Interpreter','Latex','Fontsize',15)
% title('$n_x^\prime = 0 $','Interpreter','Latex','Fontsize',15)
% 
% figure(2)
% plot(x,S(:,2));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
% ylabel('\psi(\bar{x})','Interpreter','Latex','Fontsize',15)
% title('$n_x^\prime = 1 $','Interpreter','Latex','Fontsize',15)
% 
% figure(3)
% plot(x,S(:,3));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
% ylabel('\psi(\bar{x})','Interpreter','Latex','Fontsize',15)
% title('$n_x^\prime = 2 $','Interpreter','Latex','Fontsize',15)
% 
% figure(4)
% plot(x,S(:,4));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',15)
% ylabel('\psi(\bar{x})','Interpreter','Latex','Fontsize',15)
% title('$n_x^\prime = 3 $','Interpreter','Latex','Fontsize',15)

% figure(2)
% subplot(4,2,1)
% plot(x,S(:,1).*S(:,1));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 0 \wedge n_x^\prime=1 $','Interpreter','Latex','Fontsize',10)
% subplot(4,2,2)
% plot(x,S(:,3).*S(:,3));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 2 \wedge n_x^\prime=3 $','Interpreter','Latex','Fontsize',10)
% 
% figure(3)
% subplot(1,4,1)
% plot(x,S(:,4).*S(:,4));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 4 \wedge n_x^\prime=5 $','Interpreter','Latex','Fontsize',10)
% subplot(1,4,2)
% plot(x,S(:,6).*S(:,6));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 6 \wedge n_x^\prime=7 $','Interpreter','Latex','Fontsize',10)

% figure(2)
% subplot(4,2,1)
% plot(x,S(:,1).*S(:,1));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 0 \wedge n_x^\prime=1 $','Interpreter','Latex','Fontsize',10)
% subplot(4,2,2)
% plot(x,S(:,3).*S(:,3));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 2 \wedge n_x^\prime=3 $','Interpreter','Latex','Fontsize',10)
% 
% figure(3)
% subplot(1,4,1)
% plot(x,S(:,4).*S(:,4));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 4 \wedge n_x^\prime=5 $','Interpreter','Latex','Fontsize',10)
% subplot(1,4,2)
% plot(x,S(:,6).*S(:,6));
% xlabel('$\bar{x} [l_0]$','Interpreter','Latex','Fontsize',10)
% ylabel('|\psi|^2')
% title('$n_x^\prime = 6 \wedge n_x^\prime=7 $','Interpreter','Latex','Fontsize',10)







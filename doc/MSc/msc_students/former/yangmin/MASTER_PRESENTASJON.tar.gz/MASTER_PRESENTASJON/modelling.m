clc
clear all
close all

x = -15:0.01:15;
omg = 1;
Lx = 5;
size = 20;
%%Double Dot Abs
figure(1);
V = 0.5 * omg * omg * (x.* x - 2.0*Lx.*abs(x) + Lx*Lx);
plot(x,V);
xlabel('$\bar{x}[l_0]$','interpreter', 'latex','FontSize',size);
ylabel('$V(\bar{x})$ $[E_H]$','interpreter', 'latex','FontSize',size);
title('$V_C$: $L_x = 5$, $\omega=1$','interpreter', 'latex','FontSize',size);
      
figure(2);
y = -6:0.01:6;
omg = 1;
V0 = 10;
V = 0.5*( omg * omg * y.* y + 2*V0.*exp(-y.*y*0.5));
plot(y,V,'r');
% hold all
% omg = 0.8;
% V = 0.5*( omg * omg * y.* y + 2*V0.*exp(-y.*y*0.5));
% plot(y,V);
xlabel('$\bar{x}[l_0]$','interpreter', 'latex','FontSize',size);
ylabel('$V(\bar{x})$ $[E_H]$','interpreter', 'latex','FontSize',size);
title('$V_G$: $V_0=10$, $\sigma=1$, $\omega=1$','interpreter', 'latex','FontSize',size);
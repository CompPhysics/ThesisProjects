%function plotSpheres(spheresX, spheresY, spheresZ, spheresRadius)

spheresX = [0 0 0 0 2 2 2 2];
spheresY = [0 0 2 2 0 0 2 2];
spheresZ = [0 2 0 2 0 2 0 2];
spheresRadius = [1 1 1 1 1 1 1 1];

% set up unit sphere information
numSphereFaces = 50
[unitSphereX, unitSphereY, unitSphereZ] = sphere(numSphereFaces)

% set up basic plot
figure
hold on

sphereCount = length(spheresRadius)

% for each given sphere, shift the scaled unit sphere by the
% location of the sphere and plot
for i=1:sphereCount
sphereX = spheresX(i) + unitSphereX*spheresRadius(i);
sphereY = spheresY(i) + unitSphereY*spheresRadius(i);
sphereZ = spheresZ(i) + unitSphereZ*spheresRadius(i);
surface(sphereX, sphereY, sphereZ);
end

hold off

shading interp
axis square
colormap pink
clc
clear all
close all

x = -4:0.01:4;
omg = 1;
V0 = 8;
      
figure(1);
V = 0.5 * omg * omg * x.* x +V0.*exp(-x.*x*0.5);
plot(x,V,'LineWidth', 5, 'color', 'black');
hold on

A = zeros(4);
A(:,2) = [4.5510 4.5510 4.5536 4.5536];
A(:,3) = [5.5510 5.5510 5.5536 5.5536];
A(:,1) = [-2.5 -1.7 1.7 2.5]';

plot(A(:,1),A(:,2),'r.','MarkerSize',30);
% hold on
% 
% plot(A(:,1),A(:,3),'r.','MarkerSize',30);

xlabel('$\bar{x}[l_0]$','interpreter', 'latex','FontSize',15);
ylabel('$V(\bar{x})$ $[E_H]$','interpreter', 'latex','FontSize',15);
title('$\mbox{Double Quantum Dots}$','interpreter', 'latex','FontSize',15);

figure(2);
V0 = 8;
x = -4.5:0.01:4.5;
a = 1.28;
V = 0.5 * omg * omg*x.*x + V0.*exp(-(x-a).*(x-a)*0.5) + V0.*exp(-(x+a).*(x+a)*0.5);
plot(x,V,'LineWidth', 5, 'color', 'black');
hold on

A = zeros(4);
B = zeros(2);
A(:,2) = [7.8113 7.8113 7.8131 7.8131];
A(:,1) = [-2.8 -3.4 2.8 3.4]';
B(:,2) = [8.2509 8.2509];
B(:,1) = [-0.3 0.3]';

plot(A(:,1),A(:,2),'r.','MarkerSize',30);
% hold on
% plot(B(:,1),B(:,2),'r.','MarkerSize',30);
xlabel('$\bar{x}[l_0]$','interpreter', 'latex','FontSize',15);
ylabel('$V(\bar{x})$ $[E_H]$','interpreter', 'latex','FontSize',15);
title('$\mbox{Triple Quantum Dots}$','interpreter', 'latex','FontSize',15);
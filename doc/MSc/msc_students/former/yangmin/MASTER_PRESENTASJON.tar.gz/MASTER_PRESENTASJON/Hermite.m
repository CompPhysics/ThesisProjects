% NormalizedHermiteFunctions - compute normalized Hermite functions
% over a given grid.
%
% Usage:
% H = Hermite(N,x)
%
% Input: N = integer, x = some vector of points at which we H_n(x).
%
% Output: Matrix H, size(H) == [size(x), N+1]. H(:,n+1) = H_n(x).
%
%
function H = Hermite(N, x)

H = zeros(length(x), N+1);
H(:,1) = (pi^-0.25)*exp(-x.^2/2);
if (N>=1)
    H(:,2) = sqrt(2)*x.*H(:,1);
    for n = 1:N-1
        H(:,n+2) = sqrt(2/(n+1)).*x.*H(:,n+1) - sqrt(n/(n+1))*H(:,n);
    end
end

